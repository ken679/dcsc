# Onyln Client

Onyln is an in-development Windows client for Minecraft Bedrock. It is based on the [Latite Client v2.9.1 source](https://github.com/LatiteClient/Latite/tree/v2.9.1), has been renamed and modified for Onyln, and is licensed under GPL-3.0; see [LICENSE](LICENSE) for the license text. This fork's modifications were made on 2026-11-01.

Onyln has its own client menu and currently includes VSync control and NoHurtCam. Switching resource packs from the client while staying on a server is not implemented yet.

Onyln is maintained independently and is not affiliated with Latite, Mojang, or Microsoft.

## Build

Build on Windows with Visual Studio 2022 C++ tools, CMake 3.22 or newer, Ninja, and MinGW-w64 `ld.exe` available on `PATH`. Configure and build a release DLL from a Visual Studio Developer PowerShell:

```powershell
cmake --preset x64-release
cmake --build out/build/x64-release
```

The resulting DLL is `out/build/x64-release/Onyln.dll`. Other available configure presets are `x64-debug`, `x64-relwithdebinfo`, and `x64-nightly`.

## Upstream

Onyln is a derivative work. The original Latite Client source and its GPL-3.0 license are available at [LatiteClient/Latite](https://github.com/LatiteClient/Latite). Upstream notices and source references are retained where required.
