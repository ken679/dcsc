#include "pch.h"
#include "MeshUtils.h"
#include "mc/Addresses.h"

void SDK::MeshHelpers::renderMeshImmediately(class ScreenContext* scn, class Tessellator* tess,
                                             class MaterialPtr* material) {
    char pad[0x58] {};
    using func_t = void (*)(ScreenContext*, Tessellator*, MaterialPtr*, char*);
    return reinterpret_cast<func_t>(Signatures::MeshHelpers_renderMeshImmediately.result)(scn, tess, material, pad);
}
