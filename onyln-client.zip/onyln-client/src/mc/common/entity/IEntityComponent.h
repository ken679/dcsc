#pragma once

struct IEntityComponent {};
