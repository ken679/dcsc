#pragma once

#include <filesystem>

namespace OnylnTemp {
    std::filesystem::path resolvePath(std::filesystem::path const& relative);
    void cleanup();
}
