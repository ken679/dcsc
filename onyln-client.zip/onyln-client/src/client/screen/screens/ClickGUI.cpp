#include "pch.h"
#include "ClickGUI.h"
#include "client/event/Eventing.h"
#include "client/event/events/RenderOverlayEvent.h"
#include "client/event/events/RendererCleanupEvent.h"
#include "client/event/events/RendererInitEvent.h"
#include "client/event/events/KeyUpdateEvent.h"
#include "client/event/events/ClickEvent.h"
#include "client/event/events/CharEvent.h"
#include "client/render/Renderer.h"
#include "client/Onyln.h"
#include "client/feature/module/Module.h"
#include "client/feature/module/ModuleManager.h"
#include "util/DrawContext.h"
#include "../../render/asset/Assets.h"
#include "client/config/ConfigManager.h"

#include "../ScreenManager.h"

#include <type_traits>
#include <cwctype>
#include <cmath>

#ifdef min
#undef min
#undef max
#endif
#include <client/feature/module/HUDModule.h>

#include <optional>
#include <array>

using FontSelection = Renderer::FontSelection;
using RectF = d2d::Rect;

float calcAnim = 0.f;

namespace {
    static constexpr float setting_height_relative = 0.0168f; // 0.0168

    std::wstring lowercase(std::wstring text) {
        std::ranges::transform(text, text.begin(), [](wchar_t ch) {
            return static_cast<wchar_t>(std::towlower(ch));
        });
        return text;
    }

    bool containsSearch(std::wstring text, std::wstring const& search) {
        return lowercase(std::move(text)).find(search) != std::wstring::npos;
    }

    bool settingMatchesSearch(Setting* set, std::wstring const& search) {
        if (search.empty()) return true;
        if (containsSearch(set->getDisplayName(), search)) return true;
        if (containsSearch(set->desc(), search)) return true;
        if (containsSearch(util::StrToWStr(set->name()), search)) return true;

        if (set->enumData) {
            for (auto& entry : *set->enumData->getEntries()) {
                if (containsSearch(entry.name(), search)) return true;
                if (containsSearch(entry.desc(), search)) return true;
            }
        }

        return false;
    }

    std::optional<float> parseSliderValue(std::wstring const& text) {
        if (text.empty() || std::ranges::any_of(text, [](wchar_t character) {
                return std::iswspace(character) != 0;
            })) {
            return std::nullopt;
        }

        try {
            size_t parsedCharacters = 0;
            float value = std::stof(text, &parsedCharacters);
            if (parsedCharacters != text.size() || !std::isfinite(value)) return std::nullopt;
            return value;
        } catch (std::invalid_argument const&) {
            return std::nullopt;
        } catch (std::out_of_range const&) {
            return std::nullopt;
        }
    }
}

ClickGUI::ClickGUI() {
    Onyln::get().addTextBox(&this->searchTextBox);

    Eventing::get().listen<RenderOverlayEvent>(this, (EventListenerFunc)&ClickGUI::onRender, 1, true);
    Eventing::get().listen<RendererCleanupEvent>(this, (EventListenerFunc)&ClickGUI::onCleanup, 1, true);
    Eventing::get().listen<RendererInitEvent>(this, (EventListenerFunc)&ClickGUI::onInit, 1, true);
    Eventing::get().listen<KeyUpdateEvent>(this, (EventListenerFunc)&ClickGUI::onKey, 1);
    Eventing::get().listen<ClickEvent>(this, (EventListenerFunc)&ClickGUI::onClick, 1);
}

void ClickGUI::updateScrollbarDrag(Vec2 const& mouse) {
    if (!draggingScrollbar) return;
    if (!mouseButtons[0] || scrollMax <= 0.f || scrollbarTrackRect.getHeight() <= scrollbarThumbRect.getHeight()) {
        draggingScrollbar = false;
        return;
    }

    float availableTrack = scrollbarTrackRect.getHeight() - scrollbarThumbRect.getHeight();
    float thumbTop = std::clamp(mouse.y - scrollbarDragOffset, scrollbarTrackRect.top,
                                scrollbarTrackRect.bottom - scrollbarThumbRect.getHeight());
    float normalized = (thumbTop - scrollbarTrackRect.top) / availableTrack;
    scroll = std::clamp(normalized * scrollMax, 0.f, scrollMax);
}

void ClickGUI::onRender(Event&) {
    renderOnylnMenu();
}

void ClickGUI::renderOnylnMenu() {
    if (!isActive()) return;

    auto* client = SDK::ClientInstance::get();
    if (!client) return;

    auto& renderer = Onyln::getRenderer();
    const auto screen = renderer.getScreenSize();
    if (screen.width <= 0.f || screen.height <= 0.f) return;

    adaptedScale = std::clamp(screen.height / 900.f, 0.72f, 1.25f);
    const float scale = adaptedScale;
    const float width = std::min(screen.width * 0.92f, 1260.f * scale);
    const float height = std::min(screen.height * 0.88f, 790.f * scale);
    rect = { (screen.width - width) * 0.5f, (screen.height - height) * 0.5f,
             (screen.width + width) * 0.5f, (screen.height + height) * 0.5f };

    D2DUtil dc;
    dc.ctx->SetAntialiasMode(D2D1_ANTIALIAS_MODE_PER_PRIMITIVE);
    clearLayers();

    const Vec2 cursor = client->cursorPos;
    const auto accent = d2d::Color(Onyln::get().getAccentColor().getMainColor());
    const auto panel = d2d::Color::RGB(15, 19, 29);
    const auto panelRaised = d2d::Color::RGB(23, 29, 42);
    const auto panelHover = d2d::Color::RGB(31, 39, 55);
    const auto text = d2d::Color::RGB(239, 243, 250);
    const auto muted = d2d::Color::RGB(151, 163, 181);
    const float radius = 13.f * scale;

    if (Onyln::get().getMenuBlur()) dc.drawGaussianBlur(5.f * scale);
    dc.fillRoundedRectangle(rect, panel, radius);
    dc.drawRoundedRectangle(rect, d2d::Color::RGB(63, 76, 99).asAlpha(0.65f), radius, 1.f);

    const float sidebarWidth = 190.f * scale;
    const float headerHeight = 88.f * scale;
    const d2d::Rect sidebar { rect.left, rect.top + headerHeight, rect.left + sidebarWidth, rect.bottom };
    const d2d::Rect content { sidebar.right, rect.top + headerHeight, rect.right, rect.bottom };
    dc.fillRectangle({ rect.left, rect.top + headerHeight, rect.left + 1.5f * scale, rect.bottom }, accent);

    const d2d::Rect logo { rect.left + 24.f * scale, rect.top + 21.f * scale,
                           rect.left + 64.f * scale, rect.top + 61.f * scale };
    dc.fillRoundedRectangle(logo, accent, 11.f * scale);
    dc.drawText(logo, L"N", text, FontSelection::PrimaryLight, 25.f * scale,
                DWRITE_TEXT_ALIGNMENT_CENTER, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false);
    dc.drawText({ logo.right + 13.f * scale, rect.top + 18.f * scale, rect.right - 75.f * scale,
                  rect.top + 50.f * scale }, L"Onyln Client", text, FontSelection::PrimarySemilight,
                21.f * scale, DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false);
    dc.drawText({ logo.right + 14.f * scale, rect.top + 49.f * scale, rect.right - 75.f * scale,
                  rect.top + 70.f * scale }, L"1.26.4x  |  GAME CONTROL", muted, FontSelection::PrimaryRegular,
                10.f * scale, DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false);

    const d2d::Rect closeButton { rect.right - 48.f * scale, rect.top + 23.f * scale,
                                  rect.right - 22.f * scale, rect.top + 49.f * scale };
    dc.drawText(closeButton, L"X", muted, FontSelection::PrimaryRegular, 24.f * scale,
                DWRITE_TEXT_ALIGNMENT_CENTER, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false);
    if (closeButton.contains(cursor)) {
        dc.fillRoundedRectangle(closeButton, panelHover, 7.f * scale);
        dc.drawText(closeButton, L"X", text, FontSelection::PrimaryRegular, 24.f * scale,
                    DWRITE_TEXT_ALIGNMENT_CENTER, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false);
        if (justClicked[0]) close();
    }

    const std::array<std::wstring, 4> pageNames { L"All Modules", L"Game", L"HUD", L"Settings" };
    const std::array<std::wstring, 4> pageMarks { L"A", L"G", L"H", L"S" };
    const float navLeft = rect.left + 16.f * scale;
    const float navRight = rect.left + sidebarWidth - 16.f * scale;
    const float navHeight = 43.f * scale;
    float navY = rect.top + headerHeight + 24.f * scale;
    for (int page = 0; page < static_cast<int>(pageNames.size()); ++page) {
        const d2d::Rect nav { navLeft, navY, navRight, navY + navHeight };
        const bool selected = onylnPage == page;
        const bool hovered = nav.contains(cursor);
        if (selected || hovered) {
            dc.fillRoundedRectangle(nav, selected ? accent.asAlpha(0.20f) : panelHover, 8.f * scale);
        }
        dc.drawText({ nav.left + 12.f * scale, nav.top, nav.left + 36.f * scale, nav.bottom }, pageMarks[page],
                    selected ? accent : muted, FontSelection::PrimarySemilight, 14.f * scale,
                    DWRITE_TEXT_ALIGNMENT_CENTER, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false);
        dc.drawText({ nav.left + 43.f * scale, nav.top, nav.right - 5.f * scale, nav.bottom }, pageNames[page],
                    selected ? text : muted, FontSelection::PrimaryRegular, 13.f * scale,
                    DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false);
        if (hovered && justClicked[0]) {
            onylnPage = page;
            onylnSelectedModule.reset();
            searchTextBox.setSelected(false);
            onylnModuleScroll = onylnSettingsScroll = 0.f;
            playClickSound();
        }
        navY += navHeight + 7.f * scale;
    }

    dc.drawText({ navLeft + 4.f * scale, rect.bottom - 43.f * scale, navRight, rect.bottom - 20.f * scale },
                L"GPL-3.0 base  |  Onyln UI", muted, FontSelection::PrimaryRegular, 9.f * scale,
                DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false);

    const float contentPad = 26.f * scale;
    const float contentLeft = content.left + contentPad;
    const float contentRight = content.right - contentPad;
    const float titleY = rect.top + headerHeight + 19.f * scale;
    std::wstring pageTitle = onylnPage == 1 ? L"Game modules" : onylnPage == 2 ? L"HUD modules" :
                             onylnPage == 3 ? L"Client settings" : L"Your modules";
    dc.drawText({ contentLeft, titleY, contentRight - (onylnPage == 3 ? 0.f : 250.f * scale),
                  titleY + 30.f * scale }, pageTitle, text, FontSelection::PrimarySemilight, 21.f * scale,
                DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false);

    if (onylnPage == 3) {
        dc.drawText({ contentLeft, titleY + 34.f * scale, contentRight, titleY + 56.f * scale },
                    L"Rendering, input and client behavior", muted, FontSelection::PrimaryRegular, 11.f * scale,
                    DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false);

        onylnSettingsViewport = { contentLeft, titleY + 72.f * scale, contentRight, rect.bottom - 22.f * scale };
        float settingY = onylnSettingsViewport.top - onylnSettingsScroll;
        const float settingGap = 15.f * scale;
        auto& settings = Onyln::get().getSettings();
        dc.ctx->PushAxisAlignedClip(onylnSettingsViewport.get(), D2D1_ANTIALIAS_MODE_ALIASED);
        settings.forEach([&](std::shared_ptr<Setting> set) {
            if (!set || !set->visible || !set->value || !set->shouldRender(settings)) return;
            settingY = drawSetting(set.get(), &settings, { contentLeft, settingY }, dc,
                                   onylnSettingsViewport.getWidth() - 12.f * scale) + settingGap;
        });
        dc.ctx->PopAxisAlignedClip();
        onylnSettingsScrollMax = std::max(0.f, settingY + onylnSettingsScroll - onylnSettingsViewport.bottom);
        onylnSettingsScroll = std::clamp(onylnSettingsScroll, 0.f, onylnSettingsScrollMax);
        if (colorPicker.setting) {
            addLayer(cPickerRect);
            drawColorPicker();
        }
        return;
    }

    const float searchWidth = 225.f * scale;
    const d2d::Rect searchRect { contentRight - searchWidth, titleY + 1.f * scale,
                                 contentRight, titleY + 35.f * scale };
    searchTextBox.setRect(searchRect);
    if (searchRect.contains(cursor) && justClicked[0]) searchTextBox.setSelected(true);
    else if (justClicked[0] && !searchRect.contains(cursor)) searchTextBox.setSelected(false);
    searchTextBox.render(dc, 8.f * scale, panelRaised,
                         searchTextBox.isSelected() ? text : muted);
    if (searchTextBox.getText().empty() && !searchTextBox.isSelected()) {
        dc.drawText(searchRect, L"Search modules", muted, FontSelection::PrimaryRegular, 10.f * scale,
                    DWRITE_TEXT_ALIGNMENT_CENTER, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false);
    }
    if (searchTextBox.isSelected()) dc.drawRoundedRectangle(searchRect, accent, 8.f * scale, 1.f);

    const float bodyTop = titleY + 62.f * scale;
    const float bodyBottom = rect.bottom - 22.f * scale;
    std::vector<std::shared_ptr<Module>> modules;
    const std::wstring query = lowercase(searchTextBox.getText());
    Onyln::getModuleManager().forEach([&](std::shared_ptr<Module> module) {
        if (!module || !module->isVisible()) return;
        const auto category = module->getCategory();
        if (onylnPage == 1 && category != Module::GAME && category != Module::GAMEHUD) return;
        if (onylnPage == 2 && category != Module::HUD && category != Module::GAMEHUD) return;
        if (!query.empty() && !containsSearch(module->getDisplayName(), query) &&
            !containsSearch(module->desc(), query) && !containsSearch(util::StrToWStr(module->name()), query)) {
            return;
        }
        modules.push_back(std::move(module));
    });

    dc.drawText({ contentLeft, titleY + 34.f * scale, searchRect.left - 12.f * scale, titleY + 56.f * scale },
                std::to_wstring(modules.size()) + L" modules available", muted, FontSelection::PrimaryRegular,
                10.f * scale, DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false);

    onylnModuleViewport = { contentLeft, bodyTop, contentRight, bodyBottom };
    const bool detailsOpen = static_cast<bool>(onylnSelectedModule);
    const float listWidth = detailsOpen ? onylnModuleViewport.getWidth() * 0.43f : onylnModuleViewport.getWidth();
    const float cardGap = 10.f * scale;
    const float cardHeight = detailsOpen ? 65.f * scale : 94.f * scale;
    const int columns = detailsOpen ? 1 : 2;
    const float cardWidth = detailsOpen ? listWidth : (listWidth - cardGap) * 0.5f;
    const float contentHeight = ((modules.size() + columns - 1) / columns) * (cardHeight + cardGap);
    onylnModuleScrollMax = std::max(0.f, contentHeight - onylnModuleViewport.getHeight());
    onylnModuleScroll = std::clamp(onylnModuleScroll, 0.f, onylnModuleScrollMax);

    dc.ctx->PushAxisAlignedClip({ onylnModuleViewport.left, onylnModuleViewport.top,
                                  onylnModuleViewport.left + listWidth, onylnModuleViewport.bottom },
                                D2D1_ANTIALIAS_MODE_ALIASED);
    for (size_t index = 0; index < modules.size(); ++index) {
        const int row = static_cast<int>(index) / columns;
        const int column = static_cast<int>(index) % columns;
        const float x = onylnModuleViewport.left + column * (cardWidth + cardGap);
        const float y = onylnModuleViewport.top + row * (cardHeight + cardGap) - onylnModuleScroll;
        const d2d::Rect card { x, y, x + cardWidth, y + cardHeight };
        const auto& module = modules[index];
        const bool selected = onylnSelectedModule == module;
        const bool hovered = card.contains(cursor) && onylnModuleViewport.contains(cursor);
        dc.fillRoundedRectangle(card, hovered ? panelHover : panelRaised, 9.f * scale);
        if (selected) dc.drawRoundedRectangle(card, accent.asAlpha(0.85f), 9.f * scale, 1.f);

        const float left = card.left + 13.f * scale;
        const float right = card.right - 72.f * scale;
        dc.drawSingleLineFitted({ left, card.top + 10.f * scale, right, card.top + 32.f * scale },
                                module->getDisplayName(), text, FontSelection::PrimarySemilight,
                                13.f * scale, DWRITE_TEXT_ALIGNMENT_LEADING,
                                DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false);
        if (!detailsOpen) {
            dc.drawSingleLineFitted({ left, card.top + 39.f * scale, right, card.bottom - 8.f * scale },
                                    module->desc(), muted, FontSelection::PrimaryRegular, 9.5f * scale,
                                    DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false);
        }

        const float toggleWidth = 43.f * scale;
        const d2d::Rect toggle { card.right - toggleWidth - 12.f * scale,
                                 card.centerY() - 10.f * scale,
                                 card.right - 12.f * scale, card.centerY() + 10.f * scale };
        const bool enabled = module->isEnabled();
        dc.fillRoundedRectangle(toggle, enabled ? accent : d2d::Color::RGB(59, 68, 83), 10.f * scale);
        const float knobRadius = 7.f * scale;
        const Vec2 knob { enabled ? toggle.right - 10.f * scale : toggle.left + 10.f * scale,
                          toggle.centerY() };
        dc.fillRoundedRectangle({ knob.x - knobRadius, knob.y - knobRadius,
                                  knob.x + knobRadius, knob.y + knobRadius },
                                d2d::Color::RGB(245, 247, 251), knobRadius);

        if (hovered && justClicked[0]) {
            if (toggle.contains(cursor)) {
                module->setEnabled(!enabled);
            } else {
                onylnSelectedModule = module;
                onylnSettingsScroll = 0.f;
            }
            playClickSound();
        }
    }
    dc.ctx->PopAxisAlignedClip();

    if (detailsOpen && onylnSelectedModule) {
        const float detailsLeft = onylnModuleViewport.left + listWidth + 16.f * scale;
        const d2d::Rect details { detailsLeft, bodyTop, contentRight, bodyBottom };
        dc.fillRoundedRectangle(details, panelRaised, 10.f * scale);
        const d2d::Rect backButton { details.left + 14.f * scale, details.top + 12.f * scale,
                                     details.left + 43.f * scale, details.top + 38.f * scale };
        dc.drawText(backButton, L"<", muted, FontSelection::PrimaryRegular, 24.f * scale,
                    DWRITE_TEXT_ALIGNMENT_CENTER, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false);
        if (backButton.contains(cursor) && justClicked[0]) onylnSelectedModule.reset();

        dc.drawSingleLineFitted({ details.left + 52.f * scale, details.top + 12.f * scale,
                                  details.right - 14.f * scale, details.top + 39.f * scale },
                                onylnSelectedModule->getDisplayName(), text, FontSelection::PrimarySemilight,
                                16.f * scale, DWRITE_TEXT_ALIGNMENT_LEADING,
                                DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false);
        dc.drawWrappedTextClipped({ details.left + 16.f * scale, details.top + 51.f * scale,
                                    details.right - 16.f * scale, details.top + 93.f * scale },
                                  onylnSelectedModule->desc(), muted, FontSelection::PrimaryRegular, 10.f * scale,
                                  DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_PARAGRAPH_ALIGNMENT_NEAR, false);

        onylnSettingsViewport = { details.left + 16.f * scale, details.top + 106.f * scale,
                                 details.right - 16.f * scale, details.bottom - 12.f * scale };
        float settingY = onylnSettingsViewport.top - onylnSettingsScroll;
        const float settingGap = 13.f * scale;
        float settingContentBottom = settingY;
        dc.ctx->PushAxisAlignedClip(onylnSettingsViewport.get(), D2D1_ANTIALIAS_MODE_ALIASED);
        onylnSelectedModule->settings->forEach([&](std::shared_ptr<Setting> set) {
            if (!set || !set->visible || !set->value || !set->shouldRender(*onylnSelectedModule->settings)) return;
            settingContentBottom = drawSetting(set.get(), onylnSelectedModule->settings.get(),
                                               { onylnSettingsViewport.left, settingY }, dc,
                                               onylnSettingsViewport.getWidth());
            settingY = settingContentBottom + settingGap;
        });
        dc.ctx->PopAxisAlignedClip();
        onylnSettingsScrollMax = std::max(0.f, settingY + onylnSettingsScroll - onylnSettingsViewport.bottom);
        onylnSettingsScroll = std::clamp(onylnSettingsScroll, 0.f, onylnSettingsScrollMax);
    }

    if (colorPicker.setting) {
        addLayer(cPickerRect);
        drawColorPicker();
    }
}

void ClickGUI::onRenderLegacy(Event&) {
    static std::vector<ModuleLike> mods = {};

    static size_t lastCount = 0;
    static size_t marketScriptCount = 0;

    if (shouldRebuildModLikes) {
        shouldRebuildModLikes = false;
        mods.clear();
    }

    if (mods.empty() || (Onyln::getModuleManager().size() != lastCount)) {
        lastCount = Onyln::getModuleManager().size();
        mods.clear();
        // TODO: fetch all market scripts

        auto plugins = Onyln::getPluginManager().fetchPluginsFromMarket();
        marketScriptCount = plugins.size();

        for (auto& plug : plugins) {
            ModuleLike container { plug.name, plug.desc, plug.id, plug.author, nullptr };
            container.isMarketScript = true;
            container.pluginAuthor = plug.author;

            if (PluginManager::isPluginInstalled(plug.id)) {
                container.pluginInstalled = true;
            }

            mods.emplace_back(container);
        }

        Onyln::getModuleManager().forEach([&](std::shared_ptr<Module> mod) {
            if (mod->isVisible()) {
                ModuleLike container { mod->getDisplayName(), mod->desc(), {}, {}, mod };
                mods.emplace_back(container);
            }
            return false;
        });
    }

    {
        auto scn = Onyln::getScreenManager().getActiveScreen();
        if (!isActive() && (calcAnim < 0.03f)) {
            calcAnim = 0.f;
            return;
        }
        if (scn) {
            auto scnName = scn->get().getName();
            if (scnName != this->getName()) {
                calcAnim = 0.f;
                return;
            }
        }
    }

    bool shouldArrow = true;

    if (colorPicker.setting) {
        addLayer(cPickerRect);
    }

    D2DUtil dc;
    if (!isActive()) justClicked = { false, false, false };
    dc.ctx->SetAntialiasMode(D2D1_ANTIALIAS_MODE_PER_PRIMITIVE);

    Vec2& cursorPos = SDK::ClientInstance::get()->cursorPos;
    auto accentColor = d2d::Color(Onyln::get().getAccentColor().getMainColor());
    updateScrollbarDrag(cursorPos);
    if (!mouseButtons[0]) draggingScrollbar = false;

    // auto& ev = reinterpret_cast<RenderOverlayEvent&>(evGeneric);
    auto& rend = Onyln::getRenderer();
    auto ss = rend.getScreenSize();

    adaptedScale = ss.width / 1920.f;

    float guiX = ss.width / 4.f;
    float guiY = ss.height / 4.f;
    {
        float totalWidth = ss.height * (16.f / 9.f);
        ;

        float realGuiX = totalWidth / 2.f;

        guiX = (ss.width / 2.25f) - (realGuiX / 2.f);
        guiY = (ss.height / 5.f);
    }

    rect = { guiX, guiY, ss.width - guiX, ss.height - guiY };
    float guiWidth = rect.getWidth();
    const bool rtl = Onyln::get().getL10nData().isSelectedLanguageRightToLeft();

    if (Onyln::get().getMenuBlur())
        dc.drawGaussianBlur(Onyln::get().getMenuBlur().value() * (isActive() ? 1.f : calcAnim));

    // Animation
    D2D1::Matrix3x2F oTransform;
    D2D1::Matrix3x2F currentMatr;
    if (isActive()) {
        dc.ctx->GetTransform(&oTransform);

        dc.ctx->SetTransform(
            D2D1::Matrix3x2F::Scale({ calcAnim, calcAnim }, D2D1_POINT_2F(rect.center().x, rect.center().y)));
        dc.ctx->GetTransform(&currentMatr);
    }
    calcAnim = std::lerp(calcAnim, isActive() ? 1.f : 0.f, Onyln::getRenderer().getDeltaTime() * 0.2f);

    d2d::Color outline = d2d::Color::RGB(0, 0, 0);
    outline.a = 0.28f;
    d2d::Color rcColor = d2d::Color::RGB(0x7, 0x7, 0x7);
    rcColor.a = 0.75f;
    rect.round();

    if (!isActive()) return;
    // Shadow effect stuff
    auto shadowEffect = Onyln::getRenderer().getShadowEffect();
    shadowEffect->SetValue(D2D1_SHADOW_PROP_COLOR, D2D1::Vector4F(0.f, 0.f, 0.f, 0.1f));
    auto affineTransformEffect = Onyln::getRenderer().getAffineTransformEffect();

    D2D1::Matrix3x2F mat = D2D1::Matrix3x2F::Translation(10.f * adaptedScale, 5.f * adaptedScale);
    affineTransformEffect->SetInputEffect(0, shadowEffect);
    affineTransformEffect->SetValue(D2D1_2DAFFINETRANSFORM_PROP_TRANSFORM_MATRIX, mat);
    // Shadow effect bitmap
    auto myBitmap = rend.getBitmap();
    //

    // Menu Rect
    dc.fillRoundedRectangle(rect, rcColor, 19.f * adaptedScale);
    dc.drawRoundedRectangle(rect, outline, 19.f * adaptedScale, 4.f * adaptedScale, DrawUtil::OutlinePosition::Outside);

    float offX = 0.01689f * rect.getWidth();
    float offY = 0.03191f * rect.getHeight();
    float imgSize = 0.05338f * rect.getWidth();

    RectF logoRect = d2d::rectFromStart(rect, offX, rect.top + offY, imgSize, imgSize, rtl);

    // Onyln Logo + text
    {
        {
            auto bmp = Onyln::getAssets().OnylnMark.getBitmap();

            D2D1::Matrix3x2F oMat;
            auto sz = Onyln::getRenderer().getScreenSize();

            D2D1::Matrix3x2F m;

            // dc.ctx->GetTransform(&m);
            // dc.ctx->SetTransform(D2D1::Matrix3x2F::Scale(41.f / sz.width, 41.f / sz.height) *
            // D2D1::Matrix3x2F::Translation(logoRect.left, logoRect.top) * m);
            dc.ctx->DrawBitmap(bmp, logoRect, 1.f);
            // dc.ctx->DrawImage(compositeEffect.Get(), { 0.f, 0.f });
            // dc.ctx->SetTransform(m);
        }

        // Onyln Text
        float realLogoHeight = rect.getHeight() * 0.077921f;
        float titleSize = 25.f * adaptedScale;
        std::wstring titleText = L"\x202AOnyln Client\x202C";
        float titleGap = 9.f * adaptedScale;
        float titleWidth = 500.f * adaptedScale;
        RectF titleRect = rtl ? RectF { logoRect.left - titleGap - titleWidth, logoRect.top, logoRect.left - titleGap,
                                        logoRect.top + realLogoHeight }
                              : RectF { logoRect.right + titleGap, logoRect.top, logoRect.right + titleGap + titleWidth,
                                        logoRect.top + realLogoHeight };
        dc.drawText(titleRect, titleText, d2d::Color(1.f, 1.f, 1.f, 1.f), FontSelection::PrimaryLight, titleSize,
                    DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false);
    }

    // X button / other menus
    {
        // x btn calc
        float xOffs = rect.getWidth() * 0.02217f;
        float yOffs = rect.getHeight() * 0.04432f;

        float xWidth = rect.getWidth() * 0.02323f;
        float xHeight = xWidth; // rect.getHeight() * 0.04078f;

        RectF xRect = d2d::rectFromEnd(rect, xOffs, rect.top + yOffs, xWidth, xHeight, rtl);

        auto bmp = Onyln::getAssets().xIcon.getBitmap();
        dc.ctx->DrawBitmap(bmp, xRect, 1.f);

        if (shouldSelect(xRect, cursorPos)) {
            if (justClicked[0]) {
                playClickSound();
                close();
            }
        }

        float betw = rect.getWidth() * 0.01795f;
        if (tab == SETTINGS) {
            RectF backArrowRect =
                rtl ? RectF { xRect.right + betw, xRect.top, xRect.right + betw + xWidth, xRect.bottom }
                    : RectF { xRect.left - betw - xWidth, xRect.top, xRect.left - betw, xRect.bottom };
            { dc.drawBitmapMirroredX(Onyln::getAssets().arrowBackIcon.getBitmap(), backArrowRect, rtl); }
            if (shouldSelect(backArrowRect, cursorPos)) {
                if (justClicked[0]) {
                    playClickSound();
                    this->tab = MODULES;
                }
            }
        } else if (tab == MODULES) {
            RectF hudEditRect;
            {
                float hudEditWidth = rect.getWidth() * 0.02851f;
                float hudEditHeight = rect.getHeight() * 0.04432f;
                hudEditRect = rtl ? RectF { xRect.right + betw, xRect.bottom - hudEditHeight,
                                            xRect.right + betw + hudEditWidth, xRect.bottom }
                                  : RectF { xRect.left - betw - hudEditWidth, xRect.bottom - hudEditHeight,
                                            xRect.left - betw, xRect.bottom };

                dc.ctx->DrawBitmap(Onyln::getAssets().hudEditIcon.getBitmap(), hudEditRect);

                if (shouldSelect(hudEditRect, cursorPos)) {
                    setTooltip(LocalizeString::get("client.ui.clickGui.openHudEditor.desc"));
                    if (justClicked[0]) {
                        playClickSound();
                        close();
                        Onyln::getScreenManager().showScreen<HUDEditor>(true);
                    }
                }
            }

            // settings button
            RectF settingsRect;
            {
                float setSize = rect.getWidth() * 0.02745f;
                settingsRect = rtl ? RectF { hudEditRect.right + betw, hudEditRect.bottom - setSize,
                                             hudEditRect.right + betw + setSize, hudEditRect.bottom }
                                   : RectF { hudEditRect.left - betw - setSize, hudEditRect.bottom - setSize,
                                             hudEditRect.left - betw, hudEditRect.bottom };

                if (shouldSelect(settingsRect, cursorPos)) {
                    setTooltip(LocalizeString::get("client.ui.clickGui.openSettings.desc"));
                    if (justClicked[0]) {
                        playClickSound();
                        this->tab = SETTINGS;
                    }
                }

                dc.ctx->DrawBitmap(Onyln::getAssets().cogIcon.getBitmap(), settingsRect);
            }
        }
    }

    // Search Bar + tabs
    RectF searchRect {};
    {
        float gaps = guiWidth * 0.02217f;
        float gapY = rect.getHeight() * 0.0175f;

        // prototype height = 564

        float searchWidth = guiWidth * 0.25f;
        float searchHeight = 0.0425f * rect.getHeight();
        float searchRound = searchHeight * 0.416f;

        searchRect = d2d::rectFromStart(rect, offX, logoRect.bottom + gapY, searchWidth, searchHeight, rtl);
        auto searchCol = d2d::Color::RGB(0x70, 0x70, 0x70).asAlpha(0.28f);

        if (shouldSelect(searchRect, cursorPos)) {
            cursor = Cursor::IBeam;
            shouldArrow = false;
        }

        if (justClicked[0]) {
            if (shouldSelect(searchRect, cursorPos))
                searchTextBox.setSelected(true);
            else
                searchTextBox.setSelected(false);
        }

        {
            dc.ctx->SetTarget(shadowBitmap.Get());
            dc.ctx->Clear();

            dc.ctx->SetTransform(currentMatr);

            D2D1_ROUNDED_RECT rr;
            rr.radiusX = searchRound;
            rr.radiusY = searchRound;
            rr.rect = searchRect.get();
            rend.getSolidBrush()->SetColor(searchCol.get());
            dc.ctx->FillRoundedRectangle(rr, rend.getSolidBrush());

            // Shadow

            D2D1::Matrix3x2F matr = D2D1::Matrix3x2F::Translation(5 * adaptedScale, 5 * adaptedScale);
            affineTransformEffect->SetValue(D2D1_2DAFFINETRANSFORM_PROP_TRANSFORM_MATRIX, matr);
            shadowEffect->SetValue(D2D1_SHADOW_PROP_COLOR, D2D1::Vector4F(0.f, 0.f, 0.f, 0.4f));
            shadowEffect->SetValue(D2D1_SHADOW_PROP_OPTIMIZATION, D2D1_SHADOW_OPTIMIZATION_SPEED);

            shadowEffect->SetInput(0, shadowBitmap.Get());
            compositeEffect->SetInputEffect(0, affineTransformEffect);
            compositeEffect->SetInput(1, shadowBitmap.Get());
            {
                std::wstring searchStr = L"";
                if (searchTextBox.getText().empty() && !searchTextBox.isSelected()) {
                    if (this->tab == SETTINGS) {
                        searchStr += LocalizeString::get("client.ui.clickGui.searchSettings.name").value();
                    } else if (this->tab == MODULES) {
                        searchStr += LocalizeString::get("client.ui.clickGui.search.name").value();
                    }
                } else {
                    searchStr = searchTextBox.getText();
                }
                Vec2 ts = dc.getTextSize(searchTextBox.getText().substr(0, searchTextBox.getCaretLocation()),
                                         Renderer::FontSelection::PrimaryRegular, searchRect.getHeight() / 2.f);
                RectF textSearchRect =
                    rtl ? RectF { searchRect.left + 5.f, searchRect.top,
                                  searchRect.right - 5.f - searchRect.getHeight(), searchRect.bottom }
                        : RectF { searchRect.left + 5.f + searchRect.getHeight(), searchRect.top,
                                  searchRect.right - 5.f, searchRect.bottom };
                float blinkerX = rtl ? textSearchRect.right - ts.x - 2.f : textSearchRect.left + ts.x;
                d2d::Rect blinkerRect = { blinkerX, searchRect.top + 3.f, blinkerX + 2.f, searchRect.bottom - 3.f };
                if (searchTextBox.isSelected() && searchTextBox.shouldBlink())
                    dc.fillRectangle(blinkerRect, d2d::Color::RGB(0xB9, 0xB9, 0xB9));
                dc.drawSingleLineFitted(textSearchRect, searchStr, d2d::Color::RGB(0xB9, 0xB9, 0xB9),
                                        FontSelection::PrimaryRegular, searchRect.getHeight() / 2.f,
                                        DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false);
                RectF searchIconRect =
                    rtl ? RectF { searchRect.right - searchRect.getHeight() + 3.f, searchRect.top + 6.f,
                                  searchRect.right - 10.f, searchRect.top + searchRect.getHeight() - 6.f }
                        : RectF { searchRect.left + 10.f, searchRect.top + 6.f,
                                  searchRect.left - 3.f + searchRect.getHeight(),
                                  searchRect.top + searchRect.getHeight() - 6.f };
                dc.ctx->DrawBitmap(Onyln::getAssets().searchIcon.getBitmap(), searchIconRect);
            }

            dc.ctx->SetTarget(myBitmap);
        }

        if (tab == SETTINGS) {
            // actual settings
            auto& settings = Onyln::getSettings();
            std::wstring settingSearch = lowercase(searchTextBox.getText());

            float settingWidth = rect.getWidth() / 3.f;
            float padToSettings = 0.04787f * rect.getHeight();
            float settingRowHeight = rect.getWidth() * setting_height_relative;
            float settingsBottom = rect.bottom - settingRowHeight * 1.3f;
            auto hasSettingRoom = [settingsBottom, settingRowHeight](Vec2 const& settingPos) {
                return settingPos.y + settingRowHeight <= settingsBottom;
            };
            float startColumnX = d2d::logicalColumnX(rect, offX, settingWidth, rtl);
            // float settings
            Vec2 setPos = { startColumnX, searchRect.bottom + padToSettings };
            {
                // go through all float settings
                settings.forEach([&](std::shared_ptr<Setting> set) {
                    if (hasSettingRoom(setPos)) {
                        if (set->visible && settingMatchesSearch(set.get(), settingSearch) &&
                            set->shouldRender(settings) &&
                            set->value->index() ==
                                (size_t)Setting::Type::Float /* || set->value->index() == Setting::Type::Int*/) {
                            setPos.y = drawSetting(set.get(), &settings, setPos, dc, settingWidth, 0.35f) +
                                       (setting_height_relative * rect.getHeight());
                        }
                    }
                });
            }

            // key/enum settings
            setPos.y += padToSettings;
            {
                // go through all enum settings
                settings.forEach([&](std::shared_ptr<Setting> set) {
                    if (hasSettingRoom(setPos)) {
                        if (set->visible && settingMatchesSearch(set.get(), settingSearch) &&
                            set->shouldRender(settings) &&
                            (set->value->index() == (size_t)Setting::Type::Key ||
                             set->value->index() == (size_t)Setting::Type::Enum ||
                             set->value->index() == (size_t)Setting::Type::Color ||
                             set->value->index() == (size_t)Setting::Type::Text)) {
                            setPos.y = drawSetting(set.get(), &settings, setPos, dc, settingWidth) +
                                       (setting_height_relative * rect.getHeight());
                        }
                    }
                });
            }

            // bool settings
            setPos = { d2d::logicalColumnX(rect, rect.getWidth() * (1.3f / 3.f), settingWidth, rtl),
                       searchRect.bottom + padToSettings };
            {
                // go through all bool settings
                settings.forEach([&](std::shared_ptr<Setting> set) {
                    if (hasSettingRoom(setPos)) {
                        if (set->visible && settingMatchesSearch(set.get(), settingSearch) &&
                            set->shouldRender(settings) &&
                            set->value->index() ==
                                (size_t)Setting::Type::Bool /* || set->value->index() == Setting::Type::Enum*/) {
                            setPos.y = drawSetting(set.get(), &settings, setPos, dc, settingWidth) +
                                       (setting_height_relative * rect.getHeight());
                        }
                    }
                });
            }
        } else if (tab == MODULES) {
            // all, game, hud, etc buttons
            static std::vector<std::tuple<std::string, ClickGUI::ModTab, d2d::Color, float>> modTabs = {
                { "client.ui.clickGui.tab.all.name", ALL, searchCol, 0.f },
                { "client.ui.clickGui.tab.game.name", GAME, searchCol, 0.f },
                { "client.ui.clickGui.tab.hud.name", HUD, searchCol, 0.f },
                { "client.ui.clickGui.tab.plugins.name", SCRIPT, searchCol, 0.f }
            };

            float nodeWidth = guiWidth * 0.083f;

            RectF nodeRect = rtl ? RectF { searchRect.left - gaps - nodeWidth, searchRect.top, searchRect.left - gaps,
                                           searchRect.bottom }
                                 : RectF { searchRect.right + gaps, searchRect.top, searchRect.right + gaps + nodeWidth,
                                           searchRect.bottom };
            float pressDownHeight = searchRect.getHeight() / 10.f;

            for (auto& pair : modTabs) {
                RectF renderTabRect = nodeRect;

                float pressDownTranslate = pressDownHeight * std::get<3>(pair);
                renderTabRect = renderTabRect.translate(0.f, pressDownTranslate);

                bool contains = shouldSelect(renderTabRect, cursorPos);
                std::get<2>(pair) = util::LerpColorState(std::get<2>(pair), searchCol + 0.2f, searchCol, contains);

                if (justClicked[0] && contains) {
                    this->modTab = std::get<1>(pair);
                    playClickSound();
                    scroll = 0.f;
                }

                std::get<3>(pair) = std::lerp(
                    std::get<3>(pair), ((contains && mouseButtons[0]) || modTab == std::get<1>(pair)) ? 1.f : 0.f,
                    Onyln::getRenderer().getDeltaTime() / 5.f);

                contains = shouldSelect(renderTabRect, cursorPos);

                if (pressDownTranslate < 0.01f) dc.ctx->SetTarget(shadowBitmap.Get());
                D2D1_ROUNDED_RECT rr {};
                rr.radiusX = searchRound;
                rr.radiusY = searchRound;
                rr.rect = renderTabRect.get();
                auto solidBrush = rend.getSolidBrush();
                if (this->modTab == std::get<1>(pair)) {
                    solidBrush->SetColor((std::get<2>(pair) - 0.1f).get());
                } else {
                    solidBrush->SetColor(std::get<2>(pair).get());
                }
                dc.ctx->FillRoundedRectangle(rr, rend.getSolidBrush());

                float baseColor = 1.f - (0.1f * std::get<3>(pair));
                dc.drawSingleLineFitted(renderTabRect, LocalizeString::get(std::get<0>(pair)),
                                        { baseColor, baseColor, baseColor, 0.8f }, FontSelection::PrimaryRegular,
                                        nodeRect.getHeight() / 2.f, DWRITE_TEXT_ALIGNMENT_CENTER,
                                        DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
                dc.ctx->SetTarget(myBitmap);

                auto oWidth = nodeRect.getWidth() + gaps;
                nodeRect.left += rtl ? -oWidth : oWidth;
                nodeRect.right += rtl ? -oWidth : oWidth;
            }
        }
    }

    // Panels
    if (this->tab == MODULES) {
        auto modulePad = guiWidth * 0.0317f;
        int numMods = 3;
        float modBetwPad = modulePad / 2.f;
        float totalPad = (modBetwPad * 2.f) + modulePad * 2.f;
        float modWidth = (guiWidth - totalPad) / numMods;
        float modHeight = 0.08F * rect.getHeight();
        float padFromSearchBar = 0.034F * rect.getHeight();

        float xStart = rtl ? rect.right - modulePad - modWidth : rect.left + modulePad;
        float x = xStart;
        float y = searchRect.bottom + padFromSearchBar;
        float modStartTop = y;

        dc.ctx->PushAxisAlignedClip({ rect.left, y, rect.right, rect.bottom }, D2D1_ANTIALIAS_MODE_ALIASED);
        modClip = { rect.left, y, rect.right, rect.bottom };

        y -= this->lerpScroll;

        this->scroll = std::clamp(scroll, 0.f, scrollMax);

        lerpScroll = std::lerp(lerpScroll, scroll, Onyln::getRenderer().getDeltaTime() / 5.f);

        std::vector<std::reference_wrapper<ModuleLike>> displayedModLikes;

        // filter what mods get actually displayed (search box / selected category tab), put them in displayedModLikes

        auto moduleSearch = lowercase(searchTextBox.getText());
        if (moduleSearch != lastModuleSearch) {
            lastModuleSearch = moduleSearch;
            scroll = 0.f;
            lerpScroll = 0.f;
            draggingScrollbar = false;
        }

        for (auto& mod : mods) {
            if (moduleSearch.empty()) {
                if (modTab == ALL) {
                    if (!mod.mod) continue;
                } else if (modTab == GAME) {
                    if (!mod.mod || mod.mod->getCategory() == Module::HUD) continue;
                } else if (modTab == HUD) {
                    if (!mod.mod || !mod.mod->isHud()) continue;
                } else if (modTab == SCRIPT) {
                    if (!mod.isMarketScript) continue;
                }
            } else {
                bool matches = containsSearch(mod.name, moduleSearch) ||
                               containsSearch(mod.description, moduleSearch) ||
                               containsSearch(mod.pluginAuthor, moduleSearch);
                if (mod.mod) matches = matches || containsSearch(util::StrToWStr(mod.mod->name()), moduleSearch);
                if (!matches) continue;
            }

            displayedModLikes.emplace_back(mod);
        }

        std::ranges::sort(displayedModLikes, ModuleLike::isLess);

        int i = 0;
        int row = 1;
        int column = 1;

        std::array<float, 3> columnOffs = { 0.f, 0.f, 0.f };

        // modules
        scrollMax = 0.f;

        for (auto& modLikeRef : displayedModLikes) {
            auto& mod = modLikeRef.get();

            Vec2 pos = { x, y + columnOffs[i] };
            RectF modRect = { pos.x, pos.y, pos.x + modWidth, pos.y + modHeight };

            if (jumpModule.has_value() && mod.mod && mod.mod->name() == *jumpModule) {
                scroll = pos.y - modStartTop;
                mod.isExtended = true;
            }

            float maxHoverOffset = modRect.getHeight() / 10.f;
            modRect = modRect.translate(0.f, -(maxHoverOffset * mod.lerpHover));
            RectF modRectActual = modRect;

            if (mod.modRect.has_value()) {
                if (mod.modRect->bottom < rect.top || mod.modRect->top > rect.bottom) {
                    mod.modRect->setPos({ 0.f, pos.y });
                    goto end;
                }
            }

            {
                float textHeight = 0.4f * modHeight;
                float rlBounds = modWidth * 0.04561f;

                // toggle width/height

                float togglePad = modHeight * 0.249f;
                float toggleWidth = modWidth * 0.143f;

                RectF toggleRect = rtl ? RectF { modRect.left + togglePad, modRect.top + togglePad,
                                                 modRect.left + togglePad + toggleWidth, modRect.bottom - togglePad }
                                       : RectF { modRect.right - togglePad - toggleWidth, modRect.top + togglePad,
                                                 modRect.right - togglePad, modRect.bottom - togglePad };

                // module settings calculations
                dc.ctx->SetTarget(auxiliaryBitmap.Get());
                bool renderExtended = mod.mod && mod.lerpArrowRot < 0.995f;
                if (renderExtended) {
                    // clipped section
                    {
                        dc.ctx->Clear();

                        float textSizeDesc = textHeight * 0.72f;
                        float descTextPad = textSizeDesc / 3.f;
                        std::wstring resetText = LocalizeString::get("client.ui.clickGui.reset.name");
                        float resetTextSize = toggleRect.getHeight() * 0.55f;
                        float resetPadX = toggleRect.getHeight() * 0.4f;
                        float measuredResetWidth =
                            dc.getTextSize(resetText, Renderer::FontSelection::PrimaryRegular, resetTextSize, false,
                                           false, Vec2 { 10000.f, 10000.f })
                                .x +
                            resetPadX * 2.f;
                        float resetWidth =
                            std::min(std::max(measuredResetWidth, toggleRect.getWidth()), modWidth * 0.36f);
                        RectF resetRect =
                            rtl ? RectF { modRect.left + rlBounds, modRect.bottom, modRect.left + rlBounds + resetWidth,
                                          modRect.bottom + toggleRect.getHeight() }
                                : RectF { modRect.right - rlBounds - resetWidth, modRect.bottom,
                                          modRect.right - rlBounds, modRect.bottom + toggleRect.getHeight() };
                        float descResetGap = toggleRect.getHeight() * 0.45f;
                        RectF descTextRect =
                            rtl ? RectF { resetRect.right + descResetGap, modRect.bottom, modRect.right - rlBounds,
                                          modRect.bottom + textSizeDesc + descTextPad }
                                : RectF { modRect.left + rlBounds, modRect.bottom, resetRect.left - descResetGap,
                                          modRect.bottom + textSizeDesc + descTextPad };
                        descTextRect.bottom =
                            descTextRect.top +
                            dc.getMeasuredTextHeight(descTextRect, mod.description,
                                                     Renderer::FontSelection::PrimaryRegular, textSizeDesc, 4.f) +
                            descTextPad;
                        modRectActual.bottom = std::max(descTextRect.bottom, resetRect.bottom);

                        dc.drawWrappedTextClipped(descTextRect, mod.description, d2d::Color(1.f, 1.f, 1.f, 0.57f),
                                                  FontSelection::PrimaryRegular, textSizeDesc);

                        {
                            // Reset Button
                            dc.drawRoundedRectangle(resetRect, d2d::Color::RGB(0xFB, 0x36, 0x36),
                                                    resetRect.getHeight() * (0.223f), 0.5f,
                                                    DrawUtil::OutlinePosition::Inside);

                            dc.drawSingleLineFitted(resetRect, resetText, d2d::Color::RGB(0xFB, 0x36, 0x36),
                                                    Renderer::FontSelection::PrimaryRegular, resetTextSize,
                                                    DWRITE_TEXT_ALIGNMENT_CENTER, DWRITE_PARAGRAPH_ALIGNMENT_CENTER);

                            if (resetRect.contains(cursorPos) && justClicked[0]) {
                                mod.mod->settings->forEach([&](std::shared_ptr<Setting> set) {
                                    *set->value = set->defaultValue;
                                    // std::visit([set](auto& obj) {
                                    //	static_assert(false, "");
                                    //	obj = std::get<std::remove_reference_t<decltype(obj)>>(set->defaultValue);
                                    //	}, *set->value);
                                    // });
                                });
                            }
                        }

                        float padToSetting = 0.014184f * rect.getHeight();

                        modRectActual.bottom += padToSetting;
                        mod.mod->settings->forEach([&](std::shared_ptr<Setting> set) {
                            if (set->visible) {
                                if (modRectActual.bottom <= rect.bottom) {
                                    if (set->shouldRender(*mod.mod->settings.get())) {
                                        float newY = drawSetting(set.get(), mod.mod->settings.get(),
                                                                 { descTextRect.left, modRectActual.bottom }, dc,
                                                                 descTextRect.getWidth(), 0.25f);
                                        modRectActual.bottom =
                                            (newY - modRectActual.bottom) > 2.f
                                                ? (newY + setting_height_relative * rect.getHeight() * 1.6f)
                                                : modRectActual.bottom;
                                    }
                                }
                            }
                        });

                        if (mod.mod->isHud() && static_cast<HUDModule*>(mod.mod.get())->isShowPreview()) {
                            auto rMod = static_cast<HUDModule*>(mod.mod.get());

                            RectF box = { modRectActual.left, modRectActual.bottom, modRectActual.right,
                                          modRectActual.bottom + mod.previewSize.y };

                            Vec2 drawPos = box.center(mod.previewSize);
                            D2D1::Matrix3x2F oTrans;

                            dc.ctx->GetTransform(&oTrans);
                            dc.ctx->SetTransform(D2D1::Matrix3x2F::Scale(1.f, 1.f) *
                                                 D2D1::Matrix3x2F::Translation(drawPos.x, drawPos.y));
                            rMod->render(dc, true, false);
                            mod.previewSize = rMod->getRectNonScaled().getSize();
                            dc.ctx->SetTransform(oTrans);
                            modRectActual.bottom += box.getHeight() * 1.25f;
                        }
                    }
                }
                dc.ctx->SetTarget(myBitmap);

                if (renderExtended) {
                    modRectActual.bottom =
                        (modRect.bottom + (modRectActual.getHeight() - modRect.getHeight()) * (1.f - mod.lerpArrowRot));
                    RectF clipRect = modRectActual;
                    clipRect.left -= 10.f;
                    clipRect.right += 10.f;
                    dc.ctx->PushAxisAlignedClip(clipRect.get(), D2D1_ANTIALIAS_MODE_ALIASED);
                }

                dc.fillRoundedRectangle(modRectActual, d2d::Color::RGB(0x44, 0x44, 0x44).asAlpha(0.22f),
                                        .22f * modHeight);
                dc.drawRoundedRectangle(modRectActual, accentColor.asAlpha(1.f * mod.lerpToggle), .22f * modHeight, 1.f,
                                        DrawUtil::OutlinePosition::Inside);
                ;
                if (renderExtended) {
                    dc.ctx->DrawBitmap(auxiliaryBitmap.Get());
                    dc.ctx->PopAxisAlignedClip();
                }

                // text
                auto textRect = modRect;
                if (rtl) {
                    textRect.right -= modRect.getWidth() / 6.f;
                } else {
                    textRect.left += modRect.getWidth() / 6.f;
                }

                if (mod.isMarketScript) {
                    float authorTextSize = modRect.getHeight() * 0.45f;
                    textRect.bottom -= authorTextSize;

                    auto authorRect = textRect;
                    authorRect.top = textRect.bottom;
                    authorRect.bottom = modRect.bottom;

                    dc.drawSingleLineFitted(
                        authorRect,
                        util::FormatWString(LocalizeString::get("client.ui.clickGui.pluginAuthor.name"),
                                            { mod.pluginAuthor }),
                        d2d::Color(1.f, 1.f, 1.f, 0.57f), FontSelection::PrimarySemilight,
                        authorRect.getHeight() * 0.7f, DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_PARAGRAPH_ALIGNMENT_NEAR);
                }

                float toggleNameMargin = modWidth * 0.018f;

                // Make the text end before the toggle rectangle
                if (rtl) {
                    textRect.left = toggleRect.right + toggleNameMargin;
                } else {
                    textRect.right = toggleRect.left - toggleNameMargin;
                }
                dc.drawWrappedTextClipped(textRect, mod.name, { 1.f, 1.f, 1.f, 1.f }, FontSelection::PrimaryLight,
                                          textHeight, DWRITE_TEXT_ALIGNMENT_LEADING,
                                          mod.isMarketScript ? DWRITE_PARAGRAPH_ALIGNMENT_FAR
                                                             : DWRITE_PARAGRAPH_ALIGNMENT_CENTER);

                // toggle

                if (mod.mod) {
                    if (mod.mod->shouldHoldToToggle()) {
                        d2d::Color color = d2d::Color::RGB(0xD9, 0xD9, 0xD9, 30);

                        dc.fillRoundedRectangle(toggleRect, color, toggleRect.getHeight() / 4.f);
                        dc.drawSingleLineFitted(toggleRect, util::StrToWStr(util::KeyToString(mod.mod->getKeybind())),
                                                { 1.f, 1.f, 1.f, 1.f }, Renderer::FontSelection::PrimaryRegular,
                                                toggleRect.getHeight() / 2.f, DWRITE_TEXT_ALIGNMENT_CENTER,
                                                DWRITE_PARAGRAPH_ALIGNMENT_CENTER);

                        if (this->shouldSelect(toggleRect, cursorPos)) {
                            setTooltip(LocalizeString::get("client.ui.clickGui.enableWithKeybind.desc"));
                        }

                    } else if (!mod.mod->isToggleable()) {
                        bool selectAction = this->shouldSelect(toggleRect, cursorPos);
                        if (selectAction && justClicked[0]) {
                            mod.mod->setEnabled(true);
                            playClickSound();
                        }

                        d2d::Color actionColor = selectAction ? accentColor : d2d::Color::RGB(0xD9, 0xD9, 0xD9, 30);
                        dc.fillRoundedRectangle(toggleRect, actionColor, toggleRect.getHeight() * 0.25f);
                        dc.drawSingleLineFitted(toggleRect, L"Open", { 1.f, 1.f, 1.f, 1.f },
                                                Renderer::FontSelection::PrimaryRegular, toggleRect.getHeight() * 0.45f,
                                                DWRITE_TEXT_ALIGNMENT_CENTER, DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
                    } else {
                        bool selecToggle = this->shouldSelect(toggleRect, cursorPos);
                        if (selecToggle) {
                            if (justClicked[0]) {
                                mod.mod->setEnabled(!mod.mod->isEnabled());
                                playClickSound();
                            }
                        }
                        static auto offCol = d2d::Color(mod.toggleColorOff);

                        mod.toggleColorOn =
                            util::LerpColorState(mod.toggleColorOn, accentColor + 0.2f, accentColor, selecToggle);
                        mod.toggleColorOff =
                            util::LerpColorState(mod.toggleColorOff, offCol + 0.2f, offCol, selecToggle);

                        // float aTogglePadY = toggleRect.getHeight() * 0.15f;
                        float radius = toggleRect.getHeight() * 0.35f;
                        float circleOffs = toggleWidth * 0.27f;

                        dc.fillRoundedRectangle(toggleRect,
                                                mod.mod->isEnabled() ? mod.toggleColorOn : mod.toggleColorOff,
                                                toggleRect.getHeight() / 2.f);
                        Vec2 center { rtl ? toggleRect.right - circleOffs : toggleRect.left + circleOffs,
                                      toggleRect.centerY() };
                        Vec2 center2 = center;
                        center2.x = rtl ? toggleRect.left + circleOffs : toggleRect.right - circleOffs;
                        float onDist = center2.x - center.x;

                        mod.lerpToggle = std::lerp(mod.lerpToggle, mod.mod->isEnabled() ? 1.f : 0.f,
                                                   Onyln::getRenderer().getDeltaTime() * 0.3f);

                        center.x += onDist * mod.lerpToggle;

                        dc.brush->SetColor(d2d::Color(0xB9, 0xB9, 0xB9).get());
                        dc.ctx->FillEllipse(D2D1::Ellipse({ center.x, center.y }, radius, radius), dc.brush);
                    }
                }

                RectF arrowRc = rtl ? RectF { modRect.right - modRect.getHeight() * 0.70f,
                                              modRect.top + (modRect.getHeight() * 0.4f),
                                              modRect.right - (modRect.getHeight() * 0.4f),
                                              modRect.bottom - modRect.getHeight() * 0.4f }
                                    : RectF { modRect.left + (modRect.getHeight() * 0.4f),
                                              modRect.top + (modRect.getHeight() * 0.4f),
                                              modRect.left + modRect.getHeight() * 0.70f,
                                              modRect.bottom - modRect.getHeight() * 0.4f };
                // arrow
                if (mod.mod) {
                    if (this->shouldSelect(modRect, cursorPos) && !shouldSelect(toggleRect, cursorPos)) {
                        if (justClicked[0]) {
                            mod.isExtended = !mod.isExtended;
                            // playClickSound();
                        }
                    }

                    D2D1::Matrix3x2F oMatr;
                    dc.ctx->GetTransform(&oMatr);
                    float toLerp = mod.isExtended ? 0.f : 1.f;
                    dc.ctx->SetTransform(D2D1::Matrix3x2F::Rotation((1.f - mod.lerpArrowRot) * 180.f,
                                                                    { arrowRc.centerX(), arrowRc.centerY() }) *
                                         oMatr);
                    mod.lerpArrowRot = std::lerp(mod.lerpArrowRot, toLerp, Onyln::getRenderer().getDeltaTime() * 0.3f);
                    // icon
                    dc.ctx->DrawBitmap(Onyln::getAssets().arrowIcon.getBitmap(), arrowRc.get());
                    dc.ctx->SetTransform(oMatr);
                } else if (mod.isMarketScript) {
                    if (shouldSelect(modRect, cursorPos)) {
                        setTooltip(mod.description);
                    }

                    auto installUpdateRect = toggleRect;
                    // make it twice as wide as the toggle rect
                    if (rtl) {
                        installUpdateRect.right = installUpdateRect.left + installUpdateRect.getWidth() * 1.5f;
                    } else {
                        installUpdateRect.left = installUpdateRect.right - installUpdateRect.getWidth() * 1.5f;
                    }

                    auto documentIconBitmap = Onyln::getAssets().document.getBitmap();
                    auto bitmapSize = documentIconBitmap->GetPixelSize();

                    // we can't directly use the arrow rect because the height to width ratio of the document icon is
                    // different (need it to not look stretched) height/width * width = height
                    auto documentRect = arrowRc;
                    float newWidth = arrowRc.getWidth() * 1.5f;
                    documentRect.left = documentRect.centerX(newWidth);
                    documentRect.right = documentRect.centerX(newWidth) + newWidth;
                    auto heightByWidth = static_cast<float>(bitmapSize.height) / static_cast<float>(bitmapSize.width);
                    auto height = heightByWidth * arrowRc.getWidth();

                    float heightCenter = documentRect.centerY();
                    documentRect.top = heightCenter - height / 2.f;
                    documentRect.bottom = heightCenter + height / 2.f;

                    // draw the icon
                    dc.ctx->DrawBitmap(documentIconBitmap, documentRect.get());

                    auto selecting = shouldSelect(installUpdateRect, cursorPos);
                    if (selecting && justClicked[0] && !mod.pluginInstalled) {
                        auto result = PluginManager::installScript(mod.pluginId);
                        if (!result.has_value()) {
                            auto& error = result.error();
                            Onyln::getNotifications().push(util::StrToWStr(error));
                        } else {
                            shouldRebuildModLikes = true;
                        }
                    }

                    mod.toggleColorOn =
                        util::LerpColorState(mod.toggleColorOn, accentColor + 0.2f, accentColor, selecting);
                    // draw install/update box
                    dc.fillRoundedRectangle(installUpdateRect,
                                            mod.pluginInstalled ? mod.toggleColorOff : mod.toggleColorOn,
                                            installUpdateRect.getHeight() / 4.f);
                    dc.drawSingleLineFitted(
                        installUpdateRect,
                        mod.pluginInstalled ? LocalizeString::get("client.ui.clickGui.installed.name")
                                            : LocalizeString::get("client.ui.clickGui.install.name"),
                        d2d::Colors::WHITE, FontSelection::PrimaryLight, installUpdateRect.getHeight() / 2.f,
                        DWRITE_TEXT_ALIGNMENT_CENTER, DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
                }
            }
        end:
            columnOffs[i] += modRectActual.getHeight() - modRect.getHeight();
            // set mod rect
            mod.modRect = modRectActual;

            mod.lerpHover = std::lerp(mod.lerpHover, shouldSelect(modRectActual, cursorPos) ? 1.f : 0.f,
                                      Onyln::getRenderer().getDeltaTime() / 5.f);

            // scrolling max
            float scrollYNew = std::max(0.f, (modRectActual.bottom + padFromSearchBar) - rect.bottom) + lerpScroll;
            if (scrollYNew > scrollMax) scrollMax = scrollYNew;
            if (i >= (numMods - 1)) {
                i = 0;
                row++;
                column = 0;
                y += modRect.getHeight() + padFromSearchBar;
                x = xStart;
                continue;
            } else {
                x += (rtl ? -1.f : 1.f) * (modBetwPad + modWidth);
                column++;
            }
            i++;
        }

        dc.ctx->PopAxisAlignedClip();

        if (scrollMax > 0.f) {
            float trackWidth = 4.f * adaptedScale;
            d2d::Rect visibleListRect { rect.left, modStartTop, rect.right, rect.bottom };
            float trackX = rtl ? rect.left + (modulePad * 0.5f) - trackWidth : rect.right - (modulePad * 0.5f);
            d2d::Rect track { trackX, visibleListRect.top, trackX + trackWidth, visibleListRect.bottom };
            float thumbHeight = std::max(24.f * adaptedScale,
                                         visibleListRect.getHeight() *
                                             (visibleListRect.getHeight() / (visibleListRect.getHeight() + scrollMax)));
            float thumbY = track.top + ((track.getHeight() - thumbHeight) * (scroll / scrollMax));
            scrollbarTrackRect = track;
            scrollbarThumbRect = { track.left, thumbY, track.right, thumbY + thumbHeight };
            if (!colorPicker.setting && justClicked[0] && scrollbarTrackRect.contains(cursorPos)) {
                draggingScrollbar = true;
                if (scrollbarThumbRect.contains(cursorPos)) {
                    scrollbarDragOffset = cursorPos.y - scrollbarThumbRect.top;
                } else {
                    scrollbarDragOffset = scrollbarThumbRect.getHeight() * 0.5f;
                    updateScrollbarDrag(cursorPos);
                    thumbY = track.top + ((track.getHeight() - thumbHeight) * (scroll / scrollMax));
                    scrollbarThumbRect = { track.left, thumbY, track.right, thumbY + thumbHeight };
                }
            }
            dc.fillRoundedRectangle(scrollbarTrackRect, d2d::Color::RGB(0x55, 0x55, 0x55).asAlpha(0.28f),
                                    trackWidth * 0.5f);
            dc.fillRoundedRectangle(scrollbarThumbRect,
                                    (draggingScrollbar || scrollbarThumbRect.contains(cursorPos))
                                        ? accentColor
                                        : d2d::Color::RGB(0xD2, 0xD2, 0xD2).asAlpha(0.78f),
                                    trackWidth * 0.5f);
        } else {
            scrollbarTrackRect = {};
            scrollbarThumbRect = {};
        }
    }

    dc.ctx->SetTransform(oTransform);
    dc.ctx->DrawImage(compositeEffect.Get());
    dc.ctx->SetTransform(currentMatr);

    modClip = std::nullopt;
    jumpModule = std::nullopt;

    if (colorPicker.setting) {
        drawColorPicker();
        if (colorPicker.queueClose) {
            auto& colVal = std::get<ColorValue>(*colorPicker.setting->value);
            colVal.isRGB = std::get<BoolValue>(colorPicker.rgbSelector);
            auto d2dCol = d2d::Color(util::HSVToColor(colorPicker.pickerColor)).asAlpha(colorPicker.opacityMod);
            *colorPicker.selectedColor = { d2dCol.r, d2dCol.g, d2dCol.b, d2dCol.a };
            colorPicker.setting->update();
            colorPicker.setting->userUpdate();
            colorPicker = ColorPicker();
        }
    }
    this->clearLayers();

    dc.ctx->SetTransform(oTransform);

    dc.ctx->SetTarget(Onyln::getRenderer().getBitmap());
    // dc.ctx->DrawImage(myBitmap);

    if (shouldArrow) cursor = Cursor::Arrow;
}

void ClickGUI::onInit(Event&) {
    auto myBitmap = Onyln::getRenderer().getBitmap();
    D2D1_SIZE_U bitmapSize = myBitmap->GetPixelSize();
    D2D1_PIXEL_FORMAT pixelFormat = myBitmap->GetPixelFormat();

    auto dc = Onyln::getRenderer().getDeviceContext();

    dc->CreateBitmap(bitmapSize, nullptr, 0, D2D1::BitmapProperties1(D2D1_BITMAP_OPTIONS_TARGET, pixelFormat),
                     shadowBitmap.GetAddressOf());
    dc->CreateBitmap(bitmapSize, nullptr, 0, D2D1::BitmapProperties1(D2D1_BITMAP_OPTIONS_TARGET, pixelFormat),
                     auxiliaryBitmap.GetAddressOf());
    dc->CreateEffect(CLSID_D2D1Composite, compositeEffect.GetAddressOf());
}

void ClickGUI::onCleanup(Event&) {
    compositeEffect = nullptr;
    shadowBitmap = nullptr;
    auxiliaryBitmap = nullptr;
}

void ClickGUI::onKey(Event& evGeneric) {
    auto& ev = reinterpret_cast<KeyUpdateEvent&>(evGeneric);
    if (ev.getKey() == VK_F11) return;

    if (searchTextBox.isSelected()) {
        ev.setCancelled(true);
        return;
    }
    if (this->dropdownSetting && ev.isDown() && ev.getKey() == VK_ESCAPE) {
        dropdownSetting = nullptr;
        ev.setCancelled(true);
        return;
    }
    if (this->activeSetting) {
        if (ev.isDown()) {
            if (ev.getKey() == VK_ESCAPE) {
                activeSetting = nullptr;
                ev.setCancelled(true);
                return;
            } else {
                this->capturedKey = ev.getKey();
            }
        }
    }

    if (ev.isDown() && ev.getKey() == VK_ESCAPE) {
        if (colorPicker.setting) {
            colorPicker.queueClose = true;
        } else {
            this->close();
        }
    }

    ev.setCancelled(true);
}

void ClickGUI::onClick(Event& evGeneric) {
    auto& ev = reinterpret_cast<ClickEvent&>(evGeneric);
    if (ev.getMouseButton() > 0) {
        ev.setCancelled(true);
    }

    if (ev.getClickType() == ClickEvent::ClickType::Wheel) {
        if (colorPicker.setting) {
            ev.setCancelled(true);
            return;
        }
        auto* client = SDK::ClientInstance::get();
        if (client) {
            const float delta = static_cast<float>(ev.getWheelDelta()) * 42.f * std::max(adaptedScale, 0.72f);
            if (onylnPage == 3 || (onylnSelectedModule && onylnSettingsViewport.contains(client->cursorPos))) {
                onylnSettingsScroll = std::clamp(onylnSettingsScroll - delta, 0.f, onylnSettingsScrollMax);
            } else {
                onylnModuleScroll = std::clamp(onylnModuleScroll - delta, 0.f, onylnModuleScrollMax);
            }
        }
        ev.setCancelled(true);
        return;
    }

    if (ev.getClickType() != ClickEvent::ClickType::Left) return;
}

namespace {
    void drawAlphaBar(D2DUtil& dc, d2d::Rect rect, float nodeSize, int rows) {
        float endY = rect.top;
        endY += rect.getHeight() / rows;
        float beginY = rect.top;
        // gray part
        float bs = nodeSize;

        for (int i = 0; i < rows; i++) {
            if (i % 2 == 0) {
                for (float beginX = rect.left; beginX < rect.right; beginX += bs * 2.f) {
                    float endX = std::min(rect.right, beginX + bs);
                    dc.fillRectangle({ beginX, beginY, endX, endY }, { 1.f, 1.f, 1.f, 0.5f });
                }
            } else {
                for (float beginX = rect.left + bs; beginX < rect.right; beginX += bs * 2.f) {
                    float endX = std::min(rect.right, beginX + bs);
                    dc.fillRectangle({ beginX, beginY, endX, endY }, { 1.f, 1.f, 1.f, 0.5f });
                }
            }
            beginY = endY;
            endY += rect.getHeight() / rows;
        }
    }
}

float ClickGUI::drawSetting(Setting* set, SettingGroup*, Vec2 const& pos, D2DUtil& dc, float size, float fTextWidth,
                            bool bypassClickThrough) {
    const float checkboxSize = rect.getWidth() * setting_height_relative;
    const float textSize = checkboxSize * 0.8f;
    const auto cursorPos = SDK::ClientInstance::get()->cursorPos;
    const float round = 0.1875f * checkboxSize;
    const bool rtl = Onyln::get().getL10nData().isSelectedLanguageRightToLeft();

    auto accentColor = d2d::Color(Onyln::get().getAccentColor().getMainColor());

    switch (static_cast<Setting::Type>(set->value->index())) {
    case Setting::Type::Text: {
        RectF rc = { pos.x, pos.y, (pos.x + size) - (fTextWidth * size), pos.y + checkboxSize };
        RectF txtRc = rc;
        RectF rightRc = rc;

        float labelWidth = rc.getWidth() * (fTextWidth * 1.5f);
        if (rtl) {
            txtRc.right -= labelWidth;
            rightRc.left = txtRc.right;
        } else {
            txtRc.left += labelWidth;
            rightRc.right = txtRc.left;
        }

        d2d::Color col = d2d::Color::RGB(0x8D, 0x8D, 0x8D).asAlpha(0.11f);
        std::shared_ptr<TextBox> tb;
        for (auto& items : settingBoxes) {
            if (items.first == set) {
                tb = items.second;
            }
        }

        auto& textVal = std::get<TextValue>(*set->value);
        if (!tb) {
            tb = std::make_shared<TextBox>(txtRc);
            tb->setText(textVal.str);
            tb->setCaretLocation(static_cast<int>(textVal.str.size()));
            settingBoxes[set] = tb;
            Onyln::get().addTextBox(settingBoxes[set].get());
        }
        tb->setRect(txtRc);
        tb->render(dc, round, col, D2D1::ColorF::White);
        if (tb->isSelected()) {
            dc.drawRoundedRectangle(txtRc, D2D1::ColorF::White, round, 1.f);
        }

        if (justClicked[0]) {
            if (shouldSelect(tb->getRect(), cursorPos))
                tb->setSelected(true);
            else
                tb->setSelected(false);
        }

        textVal.str = tb->getText();
        auto label = set->getDisplayName();
        rightRc.bottom = rightRc.top + dc.getMeasuredTextHeight(
                                           rightRc, label, Renderer::FontSelection::PrimarySemilight, textSize, 3.f);
        dc.drawWrappedTextClipped(rightRc, label, { 1.f, 1.f, 1.f, 1.f }, Renderer::FontSelection::PrimarySemilight,
                                  textSize);
        return std::max(txtRc.bottom, rightRc.bottom);
    } break;
    case Setting::Type::Bool: {
        RectF checkboxRect = d2d::controlAtStart(pos, size, checkboxSize, checkboxSize, rtl);
        float offs = checkboxSize * 0.66f;
        RectF textRect = d2d::labelAfterStartControl(checkboxRect, pos, size, offs, rtl);
        auto disp = set->getDisplayName();
        float labelHeight = dc.getMeasuredTextHeight(textRect, disp, FontSelection::PrimarySemilight, textSize, 3.f);
        float rowHeight = std::max(checkboxSize, labelHeight);
        checkboxRect = checkboxRect.translate(0.f, (rowHeight - checkboxSize) * 0.5f);
        textRect = d2d::labelAfterStartControl(checkboxRect, pos, size, offs, rtl);
        textRect.top = pos.y;
        textRect.bottom = pos.y + rowHeight;

        bool contains =
            bypassClickThrough ? checkboxRect.contains(cursorPos) : this->shouldSelect(checkboxRect, cursorPos);

        auto colOff = d2d::Color::RGB(0xD9, 0xD9, 0xD9).asAlpha(0.11f);
        if (!set->rendererInfo.init) {
            set->rendererInfo.init = true;
            set->rendererInfo.col[0] = colOff.r;
            set->rendererInfo.col[1] = colOff.g;
            set->rendererInfo.col[2] = colOff.b;
            set->rendererInfo.col[3] = colOff.a;
        }
        auto lerpedColor = util::LerpColorState(set->rendererInfo.col, colOff + 0.1f, colOff, contains);
        set->rendererInfo.col[0] = lerpedColor.r;
        set->rendererInfo.col[1] = lerpedColor.g;
        set->rendererInfo.col[2] = lerpedColor.b;
        set->rendererInfo.col[3] = lerpedColor.a;

        if (contains && justClicked[0]) {
            std::get<BoolValue>(*set->value) = !std::get<BoolValue>(*set->value);
            set->update();
            set->userUpdate();
            playClickSound();
        }

        dc.fillRoundedRectangle(checkboxRect, Color(set->rendererInfo.col), round);
        if (std::get<BoolValue>(*set->value)) {
            float checkWidth = 0.6f * checkboxSize;
            float checkHeight = 0.375f * checkboxSize;
            RectF markRect = { checkboxRect.left + checkWidth / 4.f, checkboxRect.top + checkHeight / 2.f,
                               checkboxRect.right - checkWidth / 4.f, checkboxRect.bottom - checkHeight / 2.f };

            dc.ctx->DrawBitmap(Onyln::getAssets().checkmarkIcon.getBitmap(), markRect);
        }

        dc.drawWrappedTextClipped(textRect, disp, { 1.f, 1.f, 1.f, 1.f }, FontSelection::PrimarySemilight, textSize);
        auto desc = set->desc();
        if (!desc.empty())
            if (contains || shouldSelect(textRect, cursorPos)) setTooltip(desc);
        return pos.y + rowHeight;
    } break;
    case Setting::Type::Action: {
        float buttonWidth = std::min(size * 0.46f, checkboxSize * 7.f);
        RectF actionRect = d2d::controlAtStart(pos, size, buttonWidth, checkboxSize, rtl);
        bool contains = bypassClickThrough ? actionRect.contains(cursorPos) : this->shouldSelect(actionRect, cursorPos);

        auto colOff = d2d::Color::RGB(0xD9, 0xD9, 0xD9).asAlpha(0.11f);
        if (!set->rendererInfo.init) {
            set->rendererInfo.init = true;
            set->rendererInfo.col[0] = colOff.r;
            set->rendererInfo.col[1] = colOff.g;
            set->rendererInfo.col[2] = colOff.b;
            set->rendererInfo.col[3] = colOff.a;
        }
        auto lerpedColor = util::LerpColorState(set->rendererInfo.col, accentColor.asAlpha(0.35f), colOff, contains);
        set->rendererInfo.col[0] = lerpedColor.r;
        set->rendererInfo.col[1] = lerpedColor.g;
        set->rendererInfo.col[2] = lerpedColor.b;
        set->rendererInfo.col[3] = lerpedColor.a;

        if (contains && justClicked[0]) {
            if (set->action) set->action.value()();
            playClickSound();
        }

        dc.fillRoundedRectangle(actionRect, Color(set->rendererInfo.col), round);
        dc.drawSingleLineFitted(actionRect, set->getDisplayName(), d2d::Colors::WHITE, FontSelection::PrimarySemilight,
                                textSize, DWRITE_TEXT_ALIGNMENT_CENTER, DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
        if (contains && !set->desc().empty()) setTooltip(set->desc());
        return actionRect.bottom;
    } break;
    case Setting::Type::Key: {
        RectF keyRect = d2d::controlAtStart(pos, size, checkboxSize * 2.f, checkboxSize, rtl);
        std::wstring text = util::StrToWStr(util::KeyToString(std::get<KeyValue>(*set->value)));
        float keyTextSize = textSize * 0.9f;
        auto ts =
            dc.getTextSize(text, FontSelection::PrimaryRegular, keyTextSize, false, false, Vec2 { 10000.f, 10000.f }) +
            Vec2(8.f, 0.f);
        float maxKeyWidth = std::max(checkboxSize * 2.f, size * 0.38f);
        float keyWidth = std::clamp(ts.x, checkboxSize * 2.f, maxKeyWidth);
        if (rtl)
            keyRect.left = keyRect.right - keyWidth;
        else
            keyRect.right = keyRect.left + keyWidth;

        float padToName = 0.006335f * rect.getWidth();
        RectF textRect = d2d::labelAfterStartControl(keyRect, pos, size, padToName, rtl);
        auto disp = set->getDisplayName();
        float labelHeight = dc.getMeasuredTextHeight(textRect, disp, FontSelection::PrimarySemilight, textSize, 3.f);
        float rowHeight = std::max(checkboxSize, labelHeight);
        keyRect = keyRect.translate(0.f, (rowHeight - checkboxSize) * 0.5f);
        textRect = d2d::labelAfterStartControl(keyRect, pos, size, padToName, rtl);
        textRect.top = pos.y;
        textRect.bottom = pos.y + rowHeight;

        bool contains = this->shouldSelect(keyRect, cursorPos);

        auto colOff = d2d::Color::RGB(0xD9, 0xD9, 0xD9).asAlpha(0.11f);
        if (!set->rendererInfo.init) {
            set->rendererInfo.init = true;
            set->rendererInfo.col[0] = colOff.r;
            set->rendererInfo.col[1] = colOff.g;
            set->rendererInfo.col[2] = colOff.b;
            set->rendererInfo.col[3] = colOff.a;
        }
        auto lerpedColor = util::LerpColorState(set->rendererInfo.col, colOff + 0.1f, colOff, contains);
        set->rendererInfo.col[0] = lerpedColor.r;
        set->rendererInfo.col[1] = lerpedColor.g;
        set->rendererInfo.col[2] = lerpedColor.b;
        set->rendererInfo.col[3] = lerpedColor.a;

        if (set == activeSetting) {
            if (justClicked[0] && !contains) {
                activeSetting = nullptr;
            }
        }

        // white outline
        if (set == activeSetting) {
            text = L"...";
        }

        dc.fillRoundedRectangle(keyRect, Color(set->rendererInfo.col), round);

        dc.drawSingleLineFitted(keyRect, text, d2d::Color(1.f, 1.f, 1.f, 1.f), FontSelection::PrimaryRegular,
                                keyTextSize, DWRITE_TEXT_ALIGNMENT_CENTER, DWRITE_PARAGRAPH_ALIGNMENT_CENTER);

        if (activeSetting == set) {
            dc.drawRoundedRectangle(keyRect, d2d::Color(1.f, 1.f, 1.f, 1.f), round);
        }
        if (activeSetting == set && this->capturedKey > 0) {
            std::get<KeyValue>(*set->value) = capturedKey;
            set->update();
            set->userUpdate();
            activeSetting = 0;
            capturedKey = 0;
        }

        dc.drawWrappedTextClipped(textRect, disp, { 1.f, 1.f, 1.f, 1.f }, FontSelection::PrimarySemilight, textSize);
        if (!set->desc().empty())
            if (shouldSelect(textRect, cursorPos)) setTooltip(set->desc());
        if (shouldSelect(keyRect, cursorPos)) {
            setTooltip(LocalizeString::get("client.ui.clickGui.rightClickReset.desc"));
            if (justClicked[0]) {
                if (!this->activeSetting) activeSetting = set;
                playClickSound();
            }
            if (justClicked[1]) {
                activeSetting = nullptr;
                std::get<KeyValue>(*set->value) = 0;
                set->update();
                set->userUpdate();
                playClickSound();
            }
        }
        return pos.y + rowHeight;
    }
    case Setting::Type::Enum: {
        RectF enumRect = d2d::controlAtStart(pos, size, checkboxSize * 2.f, checkboxSize, rtl);

        EnumValue& val = std::get<EnumValue>(*set->value);
        auto* entries = set->enumData->getEntries();
        if (!entries || entries->empty()) {
            return enumRect.bottom;
        }

        val.val = std::clamp(val.val, 0, static_cast<int>(entries->size()) - 1);

        auto colOff = d2d::Color::RGB(0xD9, 0xD9, 0xD9).asAlpha(0.11f);
        if (!set->rendererInfo.init) {
            set->rendererInfo.init = true;
            set->rendererInfo.col[0] = colOff.r;
            set->rendererInfo.col[1] = colOff.g;
            set->rendererInfo.col[2] = colOff.b;
            set->rendererInfo.col[3] = colOff.a;
        }
        auto text = set->enumData->getSelectedName();

        float entryPadX = checkboxSize * 0.42f;
        float arrowSize = checkboxSize * 0.35f;
        float arrowPad = checkboxSize * 0.45f;
        float enumTextSize = textSize * 0.9f;
        auto ts = dc.getTextSize(text, FontSelection::PrimarySemilight, enumTextSize, false, false,
                                 Vec2 { 10000.f, 10000.f }) +
                  Vec2(8.f, 0.f);
        float maxEntryTextWidth = ts.x;
        for (auto& entry : *entries) {
            maxEntryTextWidth =
                std::max(maxEntryTextWidth, dc.getTextSize(entry.name(), FontSelection::PrimaryRegular, enumTextSize,
                                                           false, false, Vec2 { 10000.f, 10000.f })
                                                .x);
        }

        float maxDropdownWidth = std::max(checkboxSize * 2.f, size * 0.45f);
        float dropdownWidth =
            std::min(maxDropdownWidth,
                     std::max(enumRect.getWidth(), maxEntryTextWidth + entryPadX * 2.f + arrowSize + arrowPad));
        if (rtl)
            enumRect.left = enumRect.right - dropdownWidth;
        else
            enumRect.right = enumRect.left + dropdownWidth;

        float padToName = 0.006335f * rect.getWidth();
        RectF textRect = d2d::labelAfterStartControl(enumRect, pos, size, padToName, rtl);
        auto label = set->getDisplayName();
        float labelHeight = dc.getMeasuredTextHeight(textRect, label, FontSelection::PrimaryRegular, textSize, 3.f);
        float rowHeight = std::max(checkboxSize, labelHeight);
        enumRect = enumRect.translate(0.f, (rowHeight - checkboxSize) * 0.5f);
        textRect = d2d::labelAfterStartControl(enumRect, pos, size, padToName, rtl);
        textRect.top = pos.y;
        textRect.bottom = pos.y + rowHeight;
        float settingBottom = pos.y + rowHeight;

        bool contains = this->shouldSelect(enumRect, cursorPos);
        bool dropdownOpen = dropdownSetting == set;
        float& dropdownAnim = dropdownAnimations[set];
        dropdownAnim = std::lerp(dropdownAnim, dropdownOpen ? 1.f : 0.f, Onyln::getRenderer().getDeltaTime() * 0.3f);
        if (dropdownOpen && dropdownAnim > 0.995f)
            dropdownAnim = 1.f;
        else if (!dropdownOpen && dropdownAnim < 0.005f)
            dropdownAnim = 0.f;
        bool renderDropdown = dropdownAnim > 0.f;

        auto lerpedColor = util::LerpColorState(set->rendererInfo.col, colOff + 0.1f, colOff, contains);
        set->rendererInfo.col[0] = lerpedColor.r;
        set->rendererInfo.col[1] = lerpedColor.g;
        set->rendererInfo.col[2] = lerpedColor.b;
        set->rendererInfo.col[3] = lerpedColor.a;

        dc.fillRoundedRectangle(enumRect, Color(set->rendererInfo.col), round);

        RectF arrowRect = rtl ? RectF { enumRect.left + arrowPad, enumRect.centerY(arrowSize),
                                        enumRect.left + arrowPad + arrowSize, enumRect.centerY(arrowSize) + arrowSize }
                              : RectF { enumRect.right - arrowPad - arrowSize, enumRect.centerY(arrowSize),
                                        enumRect.right - arrowPad, enumRect.centerY(arrowSize) + arrowSize };
        RectF selectedTextRect = rtl ? RectF { enumRect.left + arrowPad + arrowSize + entryPadX, enumRect.top,
                                               enumRect.right - entryPadX, enumRect.bottom }
                                     : RectF { enumRect.left + entryPadX, enumRect.top,
                                               enumRect.right - arrowPad - arrowSize - entryPadX, enumRect.bottom };
        dc.drawSingleLineFitted(selectedTextRect, text, d2d::Color(1.f, 1.f, 1.f, 1.f), FontSelection::PrimaryRegular,
                                enumTextSize, DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
        dc.drawBitmapRotated(Onyln::getAssets().arrowIcon.getBitmap(), arrowRect, dropdownAnim * 180.f, 0.92f);

        if (renderDropdown) {
            dc.drawRoundedRectangle(enumRect, d2d::Color(1.f, 1.f, 1.f, 1.f), round);
        }

        dc.drawWrappedTextClipped(textRect, label, { 1.f, 1.f, 1.f, 1.f }, FontSelection::PrimaryRegular, textSize);
        if (!set->desc().empty())
            if (shouldSelect(textRect, cursorPos)) setTooltip(set->desc());

        if (contains) {
            if (set->enumData->getSelectedDesc().size() > 0) {
                setTooltip(set->enumData->getSelectedDesc());
            } else
                setTooltip(set->enumData->getSelectedName());
        }

        float dropdownBottom = enumRect.bottom;
        if (renderDropdown) {
            float entryHeight = checkboxSize * 1.16f;
            float dropdownPad = checkboxSize * 0.22f;
            RectF dropdownRect = { enumRect.left, enumRect.bottom + dropdownPad, enumRect.right,
                                   enumRect.bottom + dropdownPad + entryHeight * static_cast<float>(entries->size()) };
            RectF animatedDropdownRect = dropdownRect;
            animatedDropdownRect.bottom = dropdownRect.top + dropdownRect.getHeight() * dropdownAnim;

            dc.ctx->PushAxisAlignedClip(animatedDropdownRect.get(), D2D1_ANTIALIAS_MODE_ALIASED);
            dc.fillRoundedRectangle(dropdownRect, d2d::Color::RGB(0x2E, 0x2E, 0x2E).asAlpha(0.96f), round);
            dc.drawRoundedRectangle(dropdownRect, d2d::Color(1.f, 1.f, 1.f, 0.18f), round, 0.75f,
                                    DrawUtil::OutlinePosition::Inside);

            bool clickedEntry = false;
            for (int i = 0; i < static_cast<int>(entries->size()); ++i) {
                RectF entryRect = { dropdownRect.left, dropdownRect.top + entryHeight * static_cast<float>(i),
                                    dropdownRect.right, dropdownRect.top + entryHeight * static_cast<float>(i + 1) };
                bool entryHovered = dropdownOpen && animatedDropdownRect.contains(cursorPos) &&
                                    this->shouldSelect(entryRect, cursorPos);
                bool entrySelected = i == val.val;
                if (entryHovered || entrySelected) {
                    dc.fillRoundedRectangle(entryRect,
                                            (entrySelected ? accentColor : d2d::Color::RGB(0xD9, 0xD9, 0xD9))
                                                .asAlpha(entrySelected ? 0.34f : 0.12f),
                                            round);
                }

                RectF entryTextRect = { entryRect.left + entryPadX, entryRect.top, entryRect.right - entryPadX,
                                        entryRect.bottom };
                dc.drawSingleLineFitted(entryTextRect, entries->at(i).name(), d2d::Colors::WHITE,
                                        FontSelection::PrimaryRegular, enumTextSize, DWRITE_TEXT_ALIGNMENT_LEADING,
                                        DWRITE_PARAGRAPH_ALIGNMENT_CENTER);

                if (entryHovered) {
                    auto desc = entries->at(i).desc();
                    setTooltip(desc.empty() ? entries->at(i).name() : desc);
                    if (justClicked[0]) {
                        if (val.val != i) {
                            val.val = i;
                            set->update();
                            set->userUpdate();
                        }

                        dropdownSetting = nullptr;
                        clickedEntry = true;
                        playClickSound();
                    }
                }
            }
            dc.ctx->PopAxisAlignedClip();

            if (dropdownOpen && justClicked[0] && !contains && !this->shouldSelect(dropdownRect, cursorPos) &&
                !clickedEntry) {
                dropdownSetting = nullptr;
            }

            dropdownBottom = animatedDropdownRect.bottom;
        }

        if (contains && justClicked[0]) {
            dropdownSetting = dropdownOpen ? nullptr : set;
            activeSetting = nullptr;
            playClickSound();
        }

        return renderDropdown ? std::max(dropdownBottom, settingBottom) : settingBottom;
    }
    case Setting::Type::Color: {
        float padToName = 0.006335f * rect.getWidth();

        RectF colRect = d2d::controlAtStart(pos, size, checkboxSize * 2.f, checkboxSize, rtl);
        bool contains = this->shouldSelect(colRect, cursorPos);
        std::wstring name = set->getDisplayName();

        auto& colVal = std::get<ColorValue>(*set->value);

        RectF textRect = d2d::labelAfterStartControl(colRect, pos, size, padToName, rtl);
        float labelHeight = dc.getMeasuredTextHeight(textRect, name, FontSelection::PrimarySemilight, textSize, 3.f);
        float rowHeight = std::max(checkboxSize, labelHeight);
        colRect = colRect.translate(0.f, (rowHeight - checkboxSize) * 0.5f);
        textRect = d2d::labelAfterStartControl(colRect, pos, size, padToName, rtl);
        textRect.top = pos.y;
        textRect.bottom = pos.y + rowHeight;
        contains = this->shouldSelect(colRect, cursorPos);
        dc.drawWrappedTextClipped(textRect, name, { 1.f, 1.f, 1.f, 1.f }, FontSelection::PrimarySemilight, textSize);

        ComPtr<ID2D1LinearGradientBrush> gradientBrush;
        ComPtr<ID2D1GradientStopCollection> gradientStopCollection;

        D2D1_LINEAR_GRADIENT_BRUSH_PROPERTIES prop {};
        auto ss = Onyln::getRenderer().getScreenSize();
        prop.startPoint = { 0.f, ss.height / 2.f };
        prop.endPoint = { ss.width, ss.height / 2.f };

        d2d::Color col = { colVal.getMainColor().r, colVal.getMainColor().g, colVal.getMainColor().b,
                           colVal.getMainColor().a };

        const D2D1_GRADIENT_STOP stops[] = { 0.f, col.asAlpha(1.f).get(), 1.f, col.get() };

        dc.ctx->CreateGradientStopCollection(stops, _countof(stops), gradientStopCollection.GetAddressOf());
        dc.ctx->CreateLinearGradientBrush(prop, gradientStopCollection.Get(), gradientBrush.GetAddressOf());

        gradientBrush->SetStartPoint({ colRect.left, colRect.centerY() });
        gradientBrush->SetEndPoint({ colRect.right, colRect.centerY() });
        ComPtr<ID2D1GradientStopCollection> stopCol;

        dc.fillRoundedRectangle(colRect, { 1.f, 1.f, 1.f, 0.4f }, round);
        // alpha bar

        float apad = 1.f;
        dc.ctx->PushAxisAlignedClip(
            { colRect.left + apad, colRect.top + apad, colRect.right - apad, colRect.bottom - apad },
            D2D1_ANTIALIAS_MODE_ALIASED);
        drawAlphaBar(dc, colRect, colRect.getWidth() / 8.f, 6);
        dc.ctx->PopAxisAlignedClip();

        dc.fillRoundedRectangle(colRect, gradientBrush.Get(), round);
        dc.drawRoundedRectangle(colRect, gradientBrush.Get(), round, 1.f, DrawUtil::OutlinePosition::Inside);

        if (shouldSelect(colRect, cursorPos)) {
            if (justClicked[0]) {
                playClickSound();
                colorPicker.setting = set;
                std::get<BoolValue>(colorPicker.rgbSelector) = std::get<ColorValue>(*set->value).isRGB;
                colorPicker.dragging = false;
                float pickerWidth = 0.2419f * rect.getWidth();
                cPickerRect = rtl ? RectF { colRect.right - pickerWidth, colRect.bottom + 20.f, 0.f, 0.f }
                                  : RectF { colRect.left, colRect.bottom + 20.f, 0.f, 0.f };
                colorPicker.selectedColor = &colVal.color1;
                auto sCol = *colorPicker.selectedColor;
                colorPicker.pickerColor = util::ColorToHSV({ sCol.r, sCol.g, sCol.b, sCol.a });
                colorPicker.hueMod = colorPicker.pickerColor.h / 360.f;
                colorPicker.svModX = colorPicker.pickerColor.s;
                colorPicker.svModY = 1.f - colorPicker.pickerColor.v;
                colorPicker.opacityMod = sCol.a;
            }
        }
        return pos.y + rowHeight;
    } break;
    case Setting::Type::Float: {
        float sliderHeight = (rect.getHeight() * 0.017730f);
        float textSz = textSize;
        std::wstringstream namew;
        namew << set->getDisplayName();

        std::wstringstream valueStream;
        valueStream << std::get<FloatValue>(*set->value);
        std::wstring formattedValue = valueStream.str();
        auto valueBoxIt = settingBoxes.find(set);
        std::wstring measuredValue = valueBoxIt != settingBoxes.end() && valueBoxIt->second->isSelected()
                                         ? valueBoxIt->second->getText()
                                         : formattedValue;

        RectF textRect = { pos.x, pos.y, pos.x + size, pos.y + checkboxSize };
        textRect.bottom = textRect.top +
                          dc.getMeasuredTextHeight(textRect, namew.str(), FontSelection::PrimarySemilight, textSz, 3.f);
        dc.drawWrappedTextClipped(textRect, namew.str(), d2d::Color(1.f, 1.f, 1.f, 1.f),
                                  FontSelection::PrimarySemilight, textSz);

        float sliderPadTop = checkboxSize * 0.35f;
        float sliderTop = textRect.bottom + sliderPadTop;
        float valueTextSize = sliderHeight * 1.4f;
        float valuePadX = checkboxSize * 0.35f;
        float measuredValueWidth = dc.getTextSize(measuredValue, Renderer::FontSelection::PrimarySemilight,
                                                  valueTextSize, false, false, Vec2 { 10000.f, 10000.f })
                                       .x +
                                   valuePadX * 2.f;
        float valueWidth = std::min(std::max(measuredValueWidth, checkboxSize * 2.f), size * 0.35f);
        float gapToValue = checkboxSize * 0.35f;
        float valueTextHeight =
            std::max(sliderHeight, dc.getTextLineHeight(Renderer::FontSelection::PrimarySemilight, valueTextSize));
        float valueTextTop = sliderTop + (sliderHeight - valueTextHeight) * 0.5f;
        RectF rightRect =
            rtl ? RectF { pos.x, valueTextTop, pos.x + valueWidth, valueTextTop + valueTextHeight }
                : RectF { pos.x + size - valueWidth, valueTextTop, pos.x + size, valueTextTop + valueTextHeight };
        RectF sliderRect =
            rtl ? RectF { rightRect.right + gapToValue, sliderTop, pos.x + size, sliderTop + sliderHeight }
                : RectF { pos.x, sliderTop, rightRect.left - gapToValue, sliderTop + sliderHeight };
        if (sliderRect.getWidth() < checkboxSize * 3.f) {
            if (rtl)
                sliderRect.left = std::min(sliderRect.left, sliderRect.right - checkboxSize * 3.f);
            else
                sliderRect.right = std::max(sliderRect.right, sliderRect.left + checkboxSize * 3.f);
        }

        float innerPad = 0.2f * sliderRect.getHeight();
        RectF innerSliderRect = { sliderRect.left + innerPad, sliderRect.top + innerPad, sliderRect.right - innerPad,
                                  sliderRect.bottom - innerPad };

        float min = std::get<FloatValue>(set->min);
        float max = std::get<FloatValue>(set->max);
        float interval = std::get<FloatValue>(set->interval);

        if (valueBoxIt == settingBoxes.end()) {
            auto valueBox = std::make_shared<TextBox>(rightRect);
            valueBox->setText(formattedValue);
            valueBox->setCaretLocation(static_cast<int>(formattedValue.size()));
            valueBoxIt = settingBoxes.emplace(set, std::move(valueBox)).first;
            Onyln::get().addTextBox(valueBoxIt->second.get());
        }

        auto& valueBox = *valueBoxIt->second;
        valueBox.setRect(rightRect);
        if (valueBox.isSelected()) {
            if (auto typedValue = parseSliderValue(valueBox.getText())) {
                float newValue = std::clamp(*typedValue, min, max);
                if (std::isfinite(interval) && interval > 0.f) {
                    newValue = std::round(newValue / interval) * interval;
                }
                newValue = std::clamp(newValue, min, max);
                auto& currentValue = std::get<FloatValue>(*set->value).value;
                if (newValue != currentValue) {
                    currentValue = newValue;
                    set->update();
                    set->userUpdate();
                }
            }
        } else {
            valueStream.str(L"");
            valueStream.clear();
            valueStream << std::get<FloatValue>(*set->value);
            formattedValue = valueStream.str();
            valueBox.setText(formattedValue);
            valueBox.setCaretLocation(static_cast<int>(formattedValue.size()));
        }

        auto valueBoxColor = d2d::Color::RGB(0x8D, 0x8D, 0x8D).asAlpha(0.11f);
        valueBox.render(dc, round, valueBoxColor, D2D1::ColorF::White, DWRITE_TEXT_ALIGNMENT_CENTER);
        if (valueBox.isSelected()) {
            dc.drawRoundedRectangle(rightRect, D2D1::ColorF::White, round, 1.f);
        }

        if (justClicked[0]) {
            bool selectValueBox = shouldSelect(rightRect, cursorPos);
            if (selectValueBox && !valueBox.isSelected()) playClickSound();
            valueBox.setSelected(selectValueBox);
        }

        if (!set->desc().empty() && (shouldSelect(textRect, cursorPos) || shouldSelect(sliderRect, cursorPos) ||
                                     shouldSelect(rightRect, cursorPos))) {
            setTooltip(set->desc());
        }

        if (!this->activeSetting) {
            if (justClicked[0] && shouldSelect(sliderRect, cursorPos)) {
                activeSetting = set;
                playClickSound();
            }
        } else {
            if (activeSetting == set) {
                if (!mouseButtons[0]) activeSetting = nullptr;

                float find = rtl ? (sliderRect.right - cursorPos.x) / sliderRect.getWidth()
                                 : (cursorPos.x - sliderRect.left) / sliderRect.getWidth();

                float percent = (find);

                float newVal = percent * (std::get<FloatValue>(set->max) - min);
                newVal += min;

                newVal = std::clamp(newVal, min, max);
                if (std::isfinite(interval) && interval > 0.f) {
                    newVal = std::round(newVal / interval) * interval;
                }
                newVal = std::clamp(newVal, min, max);

                std::get<FloatValue>(*set->value) = newVal;
                set->update();
                set->userUpdate();
            }
        }

        float range = max - min;
        float percent = range == 0.f ? 0.f : (std::get<FloatValue>(*set->value) - min) / range;
        percent = std::clamp(percent, 0.f, 1.f);
        float oRight = innerSliderRect.right;
        float oLeft = innerSliderRect.left;
        float newStop = 0.f;

        if (activeSetting == set) {
            newStop = cursorPos.x;
        } else {
            newStop = rtl ? sliderRect.right - (sliderRect.getWidth() * percent)
                          : sliderRect.left + (sliderRect.getWidth() * percent);
        }
        if (rtl) {
            innerSliderRect.left = std::clamp(newStop, oLeft, oRight);
        } else {
            innerSliderRect.right = std::clamp(newStop, oLeft, oRight);
        }

        dc.fillRoundedRectangle(sliderRect, d2d::Color::RGB(0x8D, 0x8D, 0x8D).asAlpha(0.11f),
                                sliderRect.getHeight() / 2.f);
        dc.fillRoundedRectangle(innerSliderRect, accentColor, innerSliderRect.getHeight() / 2.f);

        dc.brush->SetColor(d2d::Color(0xB9, 0xB9, 0xB9).get());
        dc.ctx->FillEllipse(D2D1::Ellipse({ rtl ? innerSliderRect.left : innerSliderRect.right, sliderRect.centerY() },
                                          sliderRect.getHeight() * 0.6f, sliderRect.getHeight() * 0.6f),
                            dc.brush);
        return std::max(sliderRect.bottom, rightRect.bottom);
    } break;
    default:
        return pos.y;
    }
}

bool ClickGUI::shouldSelect(d2d::Rect rc, Vec2 const& pt) {
    if (modClip) {
        if (!modClip.value().contains(pt) || !Screen::shouldSelect(rc, pt)) {
            return false;
        }
    }
    return Screen::shouldSelect(rc, pt);
}

void ClickGUI::drawColorPicker() {
    auto& cursorPos = SDK::ClientInstance::get()->cursorPos;
    const bool rtl = Onyln::get().getL10nData().isSelectedLanguageRightToLeft();
    D2DUtil dc;
    dc.ctx->SetTarget(auxiliaryBitmap.Get());
    dc.ctx->Clear();

    float rectWidth = 0.2419f * rect.getWidth();
    cPickerRect.right = cPickerRect.left + rectWidth;

    float boxWidth = 0.79f * rectWidth;
    float remPad = (rectWidth - boxWidth) / 2.f;

    // Color PIcker Text
    float textSize = 0.09f * rectWidth;
    RectF titleRect = { cPickerRect.left + remPad, cPickerRect.top + remPad, cPickerRect.right - remPad,
                        cPickerRect.top + remPad + textSize };

    {
        dc.drawSingleLineFitted(titleRect, LocalizeString::get("client.ui.clickGui.colorPicker.name"),
                                { 1.f, 1.f, 1.f, 1.f }, Renderer::FontSelection::PrimaryLight, textSize,
                                DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
    }

    float boxTop = titleRect.bottom + remPad;

    RectF boxRect = { titleRect.left, boxTop, titleRect.right, boxTop + boxWidth };

    ComPtr<ID2D1LinearGradientBrush> mainColorBrush;
    ComPtr<ID2D1LinearGradientBrush> valueBrush;
    ComPtr<ID2D1LinearGradientBrush> hueBrush;
    ComPtr<ID2D1LinearGradientBrush> alphaBrush;

    // TODO: support chroma, multiple colors
    auto& colVal = std::get<ColorValue>(*colorPicker.setting->value);
    d2d::Color col = util::HSVToColor(colorPicker.pickerColor);
    d2d::Color sCol = { colorPicker.selectedColor->r, colorPicker.selectedColor->g, colorPicker.selectedColor->b,
                        colorPicker.selectedColor->a };
    d2d::Color nsCol = util::HSVToColor({ util::ColorToHSV(sCol).h, 1.f, 1.f });
    d2d::Color baseCol = util::HSVToColor({ colorPicker.pickerColor.h, 1.f, 1.f });

    // main brush
    {
        ComPtr<ID2D1GradientStopCollection> gradientStopCollection;

        D2D1_LINEAR_GRADIENT_BRUSH_PROPERTIES prop {};
        auto ss = Onyln::getRenderer().getScreenSize();
        prop.startPoint = { boxRect.left, boxRect.top };
        prop.endPoint = { boxRect.right, boxRect.top };

        const D2D1_GRADIENT_STOP stops[] = { 0.f, { 1.f, 1.f, 1.f, 1.f }, 1.f, baseCol.get() };

        dc.ctx->CreateGradientStopCollection(stops, _countof(stops), gradientStopCollection.GetAddressOf());
        dc.ctx->CreateLinearGradientBrush(prop, gradientStopCollection.Get(), mainColorBrush.GetAddressOf());
    }

    // Value brush
    {
        ComPtr<ID2D1GradientStopCollection> gradientStopCollection;

        D2D1_LINEAR_GRADIENT_BRUSH_PROPERTIES prop {};
        auto ss = Onyln::getRenderer().getScreenSize();
        prop.startPoint = { boxRect.left, boxRect.bottom };
        prop.endPoint = { boxRect.left, boxRect.top };

        const D2D1_GRADIENT_STOP stops[] = { 0.f, { 0.f, 0.f, 0.f, 1.f }, 1.f, { 0.f, 0.f, 0.f, 0.f } };

        dc.ctx->CreateGradientStopCollection(stops, _countof(stops), gradientStopCollection.GetAddressOf());
        dc.ctx->CreateLinearGradientBrush(prop, gradientStopCollection.Get(), valueBrush.GetAddressOf());
    }
    // Draw inner part of colorpicker

    dc.fillRectangle(boxRect, mainColorBrush.Get());
    dc.fillRectangle(boxRect, valueBrush.Get());
    dc.drawRectangle(boxRect, d2d::Color::RGB(0x50, 0x50, 0x50).asAlpha(0.28f), 2.f);

    float hueBarHeight = boxRect.getHeight() * 0.0506329f;

    float padToHueBar = remPad * 0.6f;

    RectF hueBar = { boxRect.left, boxRect.bottom + padToHueBar, boxRect.right,
                     boxRect.bottom + hueBarHeight + padToHueBar };

    // Hue brush
    {
        ComPtr<ID2D1GradientStopCollection> gradientStopCollection;

        D2D1_LINEAR_GRADIENT_BRUSH_PROPERTIES prop {};
        auto ss = Onyln::getRenderer().getScreenSize();
        prop.startPoint = { hueBar.left, hueBar.top };
        prop.endPoint = { hueBar.right, hueBar.top };

        float hueMod = 0.f;

        const D2D1_GRADIENT_STOP stops[] = {
            { 0.f, d2d::Color(util::HSVToColor({ 0.f, 1.f, 1.f })).get() },
            { 1.f / 7.f, d2d::Color(util::HSVToColor({ (1.f / 7.f) * 360.f, 1.f, 1.f })).get() },
            { 2.f / 7.f, d2d::Color(util::HSVToColor({ (2.f / 7.f) * 360.f, 1.f, 1.f })).get() },
            { 3.f / 7.f, d2d::Color(util::HSVToColor({ (3.f / 7.f) * 360.f, 1.f, 1.f })).get() },
            { 4.f / 7.f, d2d::Color(util::HSVToColor({ (4.f / 7.f) * 360.f, 1.f, 1.f })).get() },
            { 5.f / 7.f, d2d::Color(util::HSVToColor({ (5.f / 7.f) * 360.f, 1.f, 1.f })).get() },
            { 6.f / 7.f, d2d::Color(util::HSVToColor({ (6.f / 7.f) * 360.f, 1.f, 1.f })).get() },
            { 1.f, d2d::Color(util::HSVToColor({ 0.f, 1.f, 1.f })).get() },
        };

        dc.ctx->CreateGradientStopCollection(stops, 8, gradientStopCollection.GetAddressOf());
        dc.ctx->CreateLinearGradientBrush(prop, gradientStopCollection.Get(), hueBrush.GetAddressOf());
    }

    dc.fillRoundedRectangle(hueBar, hueBrush.Get(), hueBar.getHeight() / 2.f);
    dc.drawRoundedRectangle(hueBar, d2d::Color::RGB(0x50, 0x50, 0x50).asAlpha(0.28f), hueBar.getHeight() / 2.f,
                            hueBar.getHeight() / 4.f, DrawUtil::OutlinePosition::Outside);

    RectF alphaBar = { hueBar.left, hueBar.bottom + padToHueBar, hueBar.right,
                       hueBar.bottom + padToHueBar + hueBarHeight };

    // Alpha brush
    {
        ComPtr<ID2D1GradientStopCollection> gradientStopCollection;

        D2D1_LINEAR_GRADIENT_BRUSH_PROPERTIES prop {};
        auto ss = Onyln::getRenderer().getScreenSize();
        prop.startPoint = { alphaBar.left, alphaBar.top };
        prop.endPoint = { alphaBar.right, alphaBar.top };

        float hueMod = 0.f;

        const D2D1_GRADIENT_STOP stops[] = { { 0.f, col.asAlpha(0.f).get() }, { 1.f, col.asAlpha(1.f).get() } };

        dc.ctx->CreateGradientStopCollection(stops, _countof(stops), gradientStopCollection.GetAddressOf());
        dc.ctx->CreateLinearGradientBrush(prop, gradientStopCollection.Get(), alphaBrush.GetAddressOf());
    }

    dc.fillRoundedRectangle(alphaBar, { 1.f, 1.f, 1.f, 0.5f }, alphaBar.getHeight() / 2.f);

    drawAlphaBar(dc, alphaBar, alphaBar.getHeight() / 2.f, 2);
    // dc.fillRoundedRectangle(hueBar, hueBrush.Get(), hueBar.getHeight() / 2.f);
    dc.fillRoundedRectangle(alphaBar, alphaBrush.Get(), alphaBar.getHeight() / 2.f);
    dc.drawRoundedRectangle(alphaBar, d2d::Color::RGB(0x37, 0x37, 0x37).asAlpha(0.88f), alphaBar.getHeight() / 2.f,
                            alphaBar.getHeight() / 3.f, DrawUtil::OutlinePosition::Outside);

    // color hex edits/displays

    std::array<std::optional<StoredColor>, 3> cols = { colVal.getMainColor(), std::nullopt, std::nullopt };

    if (colVal.isChroma) {
        cols[1] = colVal.color2;
        cols[2] = colVal.color3;
    }

    RectF lastrc = alphaBar;
    for (size_t i = 0; i < cols.size(); ++i) {
        auto& c = cols[i];
        if (c.has_value()) {
            float colorModeWidth = alphaBar.getWidth() / 4.f;
            float hexBoxWidth = alphaBar.getWidth() * 0.617f;
            float boxHeight = alphaBar.getHeight() * 2.f;
            float colorDisplayWidth = boxHeight;

            float pad = (alphaBar.getWidth() - colorModeWidth - hexBoxWidth - colorDisplayWidth) / 3.f;

            RectF totalDisplayRect = lastrc.translate(0.f, padToHueBar);
            totalDisplayRect.bottom = totalDisplayRect.top + boxHeight;
            lastrc = totalDisplayRect;
            RectF colorModeRect = { totalDisplayRect.left, totalDisplayRect.top, totalDisplayRect.left + colorModeWidth,
                                    totalDisplayRect.bottom };
            RectF hexBox = { colorModeRect.right + pad, totalDisplayRect.top, colorModeRect.right + pad + hexBoxWidth,
                             totalDisplayRect.bottom };
            RectF colorDisplayRect = { totalDisplayRect.right - pad - colorDisplayWidth, totalDisplayRect.top,
                                       totalDisplayRect.right - pad, totalDisplayRect.bottom };

            if (pickerTextBoxes.size() <= i) {
                pickerTextBoxes.insert(pickerTextBoxes.begin() + i, TextBox(hexBox, 7));
                Onyln::get().addTextBox(&pickerTextBoxes[i]);
            }
            auto& tb = pickerTextBoxes[i];

            auto bgCol = d2d::Color::RGB(0x50, 0x50, 0x50).asAlpha(0.28f);

            auto round = 0.1875f * colorModeRect.getHeight();

            dc.fillRoundedRectangle(colorModeRect, bgCol, round);
            // dc.fillRoundedRectangle(hexBox, bgCol, round);
            dc.fillRoundedRectangle(colorDisplayRect, col.asAlpha(colorPicker.opacityMod), round);

            std::wstring alphaTxt = util::StrToWStr(std::format("{:.2f}", colorPicker.opacityMod));

            dc.drawText(colorDisplayRect, alphaTxt,
                        (colorPicker.opacityMod < 0.5f || colorPicker.pickerColor.v < 0.5f) ? D2D1::ColorF::White
                                                                                            : D2D1::ColorF::Black,
                        Renderer::FontSelection::PrimaryRegular, colorDisplayRect.getHeight() * 0.5f,
                        DWRITE_TEXT_ALIGNMENT_CENTER, DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
            tb.setRect(hexBox);

            if (!tb.isSelected()) {
                tb.setText(util::StrToWStr("#" + col.getHex()));
            }

            tb.render(dc, round, bgCol, D2D1::ColorF::White);
            if (tb.isSelected()) {
                d2d::Color newCol = col;
                std::string txt = util::WStrToStr(tb.getText());
                if (txt[0] == '#') {
                    txt = txt.substr(1);
                }
                if (txt.size() == 6) try {
                        newCol = d2d::Color::Hex(txt);
                    } catch (...) {}

                auto newHSV = util::ColorToHSV(newCol);
                colorPicker.svModX = newHSV.s;
                colorPicker.svModY = 1.f - newHSV.v;
                colorPicker.hueMod = newHSV.h / 360.f;
            } else {
                tb.setCaretLocation(static_cast<int>(tb.getText().size()));
            }

            if (justClicked[0]) {
                tb.setSelected(hexBox.contains(cursorPos));
            }

            // rgb setting
            colorPicker.rgbSetting.value = &colorPicker.rgbSelector;
            drawSetting(&colorPicker.rgbSetting, nullptr,
                        { alphaBar.left, alphaBar.bottom + hexBox.getHeight() * 1.5f }, dc, 150.f, 0.21f, true);
        }
    }

    float ellipseRadius = 0.75f * alphaBar.getHeight();

    // sv
    if (colorPicker.isEditingSV || (justClicked[0] && boxRect.contains(cursorPos))) {
        colorPicker.svModX =
            std::max(std::min(cursorPos.x - boxRect.left, boxRect.getWidth()) / boxRect.getWidth(), 0.f);
        colorPicker.svModY =
            std::max(std::min(cursorPos.y - boxRect.top, boxRect.getHeight()) / boxRect.getHeight(), 0.f);

        colorPicker.isEditingSV = true;
    }

    // hue
    if (colorPicker.isEditingHue || (justClicked[0] && hueBar.contains(cursorPos))) {
        colorPicker.hueMod = std::max(std::min(cursorPos.x - hueBar.left, hueBar.getWidth()) / hueBar.getWidth(), 0.f);
        colorPicker.isEditingHue = true;
    }

    // alpha
    if (colorPicker.isEditingOpacity || (justClicked[0] && alphaBar.contains(cursorPos))) {
        colorPicker.opacityMod =
            std::max(std::min(cursorPos.x - alphaBar.left, alphaBar.getWidth()) / alphaBar.getWidth(), 0.f);

        float val = colorPicker.opacityMod;

        float interval = 0.05f;

        // Find a good value to set to ("latch to nearest")
        val /= interval;
        val = std::round(val);
        val *= interval;

        colorPicker.opacityMod = val;
        colorPicker.isEditingOpacity = true;
    }

    if (!mouseButtons[0]) {
        colorPicker.isEditingSV = false;
        colorPicker.isEditingHue = false;
        colorPicker.isEditingOpacity = false;
    }

    {
        colorPicker.pickerColor.h = (colorPicker.hueMod * 360.f);
        colorPicker.pickerColor.s = colorPicker.svModX;
        colorPicker.pickerColor.v = 1.f - colorPicker.svModY;
    }

    // SV
    {
        auto ellipse = D2D1::Ellipse({ boxRect.left + (hueBar.getWidth() * colorPicker.svModX),
                                       boxRect.top + (boxRect.getHeight() * colorPicker.svModY) },
                                     ellipseRadius, ellipseRadius);
        dc.brush->SetColor(col.asAlpha(1.f).get());
        dc.ctx->FillEllipse(ellipse, dc.brush);
        dc.brush->SetColor(D2D1::ColorF(D2D1::ColorF::White));
        dc.ctx->DrawEllipse(ellipse, dc.brush, ellipseRadius / 2.f);
    }

    // hue
    {
        auto ellipse = D2D1::Ellipse({ hueBar.left + (hueBar.getWidth() * colorPicker.hueMod), hueBar.centerY() },
                                     ellipseRadius, ellipseRadius);
        auto huedCol = util::HSVToColor({ colorPicker.hueMod * 360.f, 1.f, 1.f });
        dc.brush->SetColor(d2d::Color(huedCol).get());
        dc.ctx->FillEllipse(ellipse, dc.brush);
        dc.brush->SetColor(D2D1::ColorF(D2D1::ColorF::White));
        dc.ctx->DrawEllipse(ellipse, dc.brush, ellipseRadius / 2.f);
    }

    // alpha
    {
        auto ellipse =
            D2D1::Ellipse({ alphaBar.left + (alphaBar.getWidth() * colorPicker.opacityMod), alphaBar.centerY() },
                          ellipseRadius, ellipseRadius);
        dc.brush->SetColor(col.asAlpha(colorPicker.opacityMod).get());
        dc.ctx->FillEllipse(ellipse, dc.brush);
        dc.brush->SetColor(D2D1::ColorF(D2D1::ColorF::White));
        dc.ctx->DrawEllipse(ellipse, dc.brush, ellipseRadius / 2.f);
    }

    cPickerRect.bottom = alphaBar.bottom + remPad * 2.f + 50.f;

    dc.ctx->SetTarget(Onyln::getRenderer().getBitmap());

    // draw menu

    dc.fillRoundedRectangle(cPickerRect, d2d::Color::RGB(0x7, 0x7, 0x7).asAlpha(0.8f), 19.f * adaptedScale);
    dc.drawRoundedRectangle(cPickerRect, d2d::Color::RGB(0, 0, 0).asAlpha(0.28f), 19.f * adaptedScale,
                            4.f * adaptedScale, DrawUtil::OutlinePosition::Outside);

    // x button
    float xWidth = 0.06f * rectWidth;
    RectF xRect = rtl ? RectF { cPickerRect.left + xWidth, cPickerRect.top + xWidth, cPickerRect.left + xWidth * 2.f,
                                cPickerRect.top + xWidth * 2.f }
                      : RectF { cPickerRect.right - xWidth * 2.f, cPickerRect.top + xWidth, cPickerRect.right - xWidth,
                                cPickerRect.top + xWidth * 2.f };
    dc.ctx->DrawBitmap(Onyln::getAssets().xIcon.getBitmap(), xRect);

    if (justClicked[0] && xRect.contains(cursorPos)) {
        colorPicker.queueClose = true;
        playClickSound();
    }

    // inner contents
    dc.ctx->DrawBitmap(auxiliaryBitmap.Get());

    RectF pickerTopBar = { cPickerRect.left, cPickerRect.top, cPickerRect.right, boxRect.top };

    if (!colorPicker.dragging && justClicked[0] && pickerTopBar.contains(cursorPos)) {
        colorPicker.dragging = true;
        colorPicker.dragOffs = cursorPos - cPickerRect.getPos();
    }

    if (!mouseButtons[0]) colorPicker.dragging = false;

    if (colorPicker.dragging) {
        cPickerRect.setPos(cursorPos - colorPicker.dragOffs);
    }

    auto ss = Onyln::getRenderer().getScreenSize();
    util::KeepInBounds(cPickerRect, { 0.f, 0.f, ss.width, ss.height });
}

void ClickGUI::onEnable(bool ignoreAnims) {
    calcAnim = 0.f;
    if (ignoreAnims) calcAnim = 1.f;
    scroll = 0.f;
    lerpScroll = 0.f;
    mouseButtons = {};
    justClicked = {};
    draggingScrollbar = false;
    dropdownSetting = nullptr;
    dropdownAnimations.clear();
    this->tab = MODULES;
}

void ClickGUI::onDisable() {
    capturedKey = 0;
    activeSetting = nullptr;
    dropdownSetting = nullptr;
    draggingScrollbar = false;
    dropdownAnimations.clear();
    searchTextBox.reset();
    searchTextBox.setSelected(false);

    for (auto& tb : this->settingBoxes) {
        tb.second->setSelected(false);
    }

    for (auto& tb : this->pickerTextBoxes) {
        tb.setSelected(false);
    }

    Onyln::getConfigManager().saveCurrentConfig();
}
