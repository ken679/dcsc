#include "pch.h"
#include "ClientScriptingObject.h"
#include "util/Util.h"
#include "util/ChakraUtil.h"
#include "client/Onyln.h"
#include "client/script/PluginManager.h"
#include "client/feature/command/CommandManager.h"
#include "client/feature/module/ModuleManager.h"
#include "../class/classes/game/JsItemStack.h"

#include "../class/classes/JsModuleClass.h"
#include "client/feature/command/script/JsCommand.h"
#include <client/feature/module/script/JsTextModule.h>
#include <client/script/class/classes/JsTextModuleClass.h>
#include <client/screen/ScreenManager.h>

JsValueRef ClientScriptingObject::registerEventCallback(JsValueRef callee, bool isConstructor, JsValueRef* arguments,
                                                        unsigned short argCount, void* callbackState) {
    JsValueRef undefined;
    JS::JsGetUndefinedValue(&undefined);
    if (!Chakra::VerifyArgCount(argCount, 3, true, true)) return undefined;
    if (!Chakra::VerifyParameters({ { arguments[1], JsString },
                                    { arguments[2], JsFunction },
                                    { Chakra::TryGet(arguments, argCount, 3), JsNumber, true } }))
        return undefined;

    const wchar_t* myS;
    size_t sze;
    JS::JsStringToPointer(arguments[1], &myS, &sze);
    std::wstring wstr(myS);

    for (auto& lis : Onyln::getPluginManager().eventListeners) {
        if (lis.first == wstr) {
            JsContextRef ct;
            JS::JsGetCurrentContext(&ct);
            JS::JsAddRef(arguments[2], nullptr);

            auto priority = Chakra::TryGet(arguments, argCount, 3);
            lis.second.push_back({ priority ? Chakra::GetInt(priority) : 0, arguments[2], ct });

            std::ranges::sort(lis.second, [](auto& left, auto& right) {
                return std::get<0>(left) > std::get<0>(right);
            });
            return undefined;
        }
    }

    Chakra::ThrowError(L"Invalid event " + wstr);
    return undefined;
}

JsValueRef ClientScriptingObject::runCommandCallback(JsValueRef callee, bool isConstructor, JsValueRef* arguments,
                                                     unsigned short argCount, void* callbackState) {
    if (!Chakra::VerifyArgCount(argCount, 2)) return Chakra::GetFalse();
    if (!Chakra::VerifyParameters({ { arguments[1], JsString } })) return JS_INVALID_REFERENCE;
    auto s = Chakra::GetString(arguments[1]);
    return Onyln::getCommandManager().runCommand(Onyln::getCommandManager().prefix + util::WStrToStr(s))
               ? Chakra::GetTrue()
               : Chakra::GetFalse();
}

JsValueRef ClientScriptingObject::showNotifCallback(JsValueRef callee, bool isConstructor, JsValueRef* arguments,
                                                    unsigned short argCount, void* callbackState) {
    JsValueRef undefined;
    JS::JsGetUndefinedValue(&undefined);
    if (!Chakra::VerifyArgCount(argCount, 2)) return undefined;
    if (!Chakra::VerifyParameters({ { arguments[1], JsString } })) return undefined;

    Onyln::getNotifications().push(JsScript::getThis()->getPlugin()->getName() + L": " +
                                    Chakra::GetString(arguments[1]));
    return undefined;
}

JsValueRef ClientScriptingObject::getMmgrCallback(JsValueRef callee, bool isConstructor, JsValueRef* arguments,
                                                  unsigned short argCount, void* callbackState) {
    JsValueRef undefined;
    JS::JsGetUndefinedValue(&undefined);
    if (!Chakra::VerifyArgCount(argCount, 1)) return undefined;
    return reinterpret_cast<ClientScriptingObject*>(callbackState)->moduleManager;
}

JsValueRef ClientScriptingObject::getCmgrCallback(JsValueRef callee, bool isConstructor, JsValueRef* arguments,
                                                  unsigned short argCount, void* callbackState) {
    JsValueRef undefined;
    JS::JsGetUndefinedValue(&undefined);
    if (!Chakra::VerifyArgCount(argCount, 1)) return undefined;
    return reinterpret_cast<ClientScriptingObject*>(callbackState)->commandManager;
}

JsValueRef ClientScriptingObject::getSmgrCallback(JsValueRef callee, bool isConstructor, JsValueRef* arguments,
                                                  unsigned short argCount, void* callbackState) {
    JsValueRef undefined;
    JS::JsGetUndefinedValue(&undefined);
    if (!Chakra::VerifyArgCount(argCount, 1)) return undefined;
    return reinterpret_cast<ClientScriptingObject*>(callbackState)->screenManager;
}

JsValueRef ClientScriptingObject::testCallback(JsValueRef callee, bool isConstructor, JsValueRef* arguments,
                                               unsigned short argCount, void* callbackState) {
    return JsScript::getThis()->getClass<JsItemStack>()->construct(
        SDK::ClientInstance::get()->getLocalPlayer()->supplies->inventory->getItem(0), false);
}

void ClientScriptingObject::initModuleManager() {
    JS::JsCreateObject(&this->moduleManager);
    JS::JsAddRef(moduleManager, nullptr);
}

void ClientScriptingObject::initCommandManager() {
    JS::JsCreateObject(&this->commandManager);
    JS::JsAddRef(commandManager, nullptr);
}

void ClientScriptingObject::initScreenManager() {
    JS::JsCreateObject(&this->commandManager);
    JS::JsAddRef(commandManager, nullptr);
}

void ClientScriptingObject::initialize(JsContextRef ctx, JsValueRef parentObj) {
#if ONYLN_DEBUG
    Chakra::DefineFunc(object, testCallback, L"test", this);
#endif

    Chakra::DefineFunc(object, registerEventCallback, L"on");
    Chakra::DefineFunc(object, runCommandCallback, L"runCommand");
    Chakra::DefineFunc(object, showNotifCallback, L"showNotification");
    Chakra::DefineFunc(object, getMmgrCallback, L"getModuleManager", this);
    Chakra::DefineFunc(object, getCmgrCallback, L"getCommandManager", this);
    Chakra::DefineFunc(object, getSmgrCallback, L"getScreenManager", this);

    initModuleManager();
    initCommandManager();
    initScreenManager();

    Chakra::DefineFunc(moduleManager, mmgrRegisterModuleCallback, L"registerModule");
    Chakra::DefineFunc(moduleManager, mmgrGetModuleByName, L"getModuleByName");
    Chakra::DefineFunc(moduleManager, mmgrForEachModule, L"forEachModule");
    Chakra::DefineFunc(commandManager, cmgrRegisterCommandCallback, L"registerCommand");
    Chakra::DefineFunc(commandManager, cmgrGetPrefixCallback, L"getPrefix");
    Chakra::DefineFunc(commandManager, smgrRegisterScreenCallback, L"registerScreen");

    Chakra::SetPropertyString(object, L"version",
                              util::StrToWStr(std::string(Onyln::version.data(), Onyln::version.size())));
}

JsValueRef ClientScriptingObject::mmgrRegisterModuleCallback(JsValueRef callee, bool isConstructor,
                                                             JsValueRef* arguments, unsigned short argCount,
                                                             void* callbackState) {
    JsValueRef undefined;
    JS::JsGetUndefinedValue(&undefined);
    if (!Chakra::VerifyArgCount(argCount, 2)) return undefined;

    auto sz = Chakra::VerifyParameters({ { arguments[1], JsObject } });
    if (!sz.success) {
        // handle
        Chakra::ThrowError(sz.str);
        return undefined;
    }

    JsModule* mod = nullptr;

    JS::JsGetExternalData(arguments[1], reinterpret_cast<void**>(&mod));

    if (!mod) {
        Chakra::ThrowError(L"Object is not a module");
        return undefined;
    }

    if (Onyln::getModuleManager().registerScriptModule(mod)) {
        JsScript::getThis()->addResource(mod, [](void* obj) {
            if (!Onyln::getModuleManager().deregisterScriptModule(reinterpret_cast<JsModule*>(obj))) {
                Logger::Warn("Module is already deregistered");
            }

            // hoepfully this doesnt double delete...
            // delete reinterpret_cast<JsModule*>(obj);
        });
    }

    return undefined;
}

JsValueRef ClientScriptingObject::mmgrDeregisterModuleCallback(JsValueRef callee, bool isConstructor,
                                                               JsValueRef* arguments, unsigned short argCount,
                                                               void* callbackState) {
    JsValueRef undefined;
    JS::JsGetUndefinedValue(&undefined);
    if (!Chakra::VerifyArgCount(argCount, 2)) return undefined;

    auto sz = Chakra::VerifyParameters({ { arguments[1], JsObject } });
    if (!sz.success) {
        // handle
        Chakra::ThrowError(sz.str);
        return undefined;
    }

    JsModule* mod = nullptr;

    JS::JsGetExternalData(arguments[1], reinterpret_cast<void**>(&mod));

    if (!mod || !(mod->getCategory() == Module::SCRIPT)) {
        Chakra::ThrowError(L"Object is not a valid script module");
        return undefined;
    }

    // Onyln::getModuleManager().deregisterScriptModule(mod);
    JsScript::getThis()->removeResource(mod); // this should deregister it I think

    return undefined;
}

JsValueRef ClientScriptingObject::mmgrGetModuleByName(JsValueRef callee, bool isConstructor, JsValueRef* arguments,
                                                      unsigned short argCount, void* callbackState) {
    JsValueRef null;
    JS::JsGetNullValue(&null);

    if (!Chakra::VerifyArgCount(argCount, 2)) return null;

    auto sz = Chakra::VerifyParameters({ { arguments[1], JsString } });
    if (!sz.success) {
        // handle
        Chakra::ThrowError(sz.str);
        return null;
    }

    std::string str = util::WStrToStr(Chakra::GetString(arguments[1]));

    auto thi = reinterpret_cast<ClientScriptingObject*>(callbackState);
    auto mod = Onyln::getModuleManager().find(str);

    JsContextRef ctx;
    JS::JsGetCurrentContext(&ctx);
    JsScript* script = JsScript::getThis();

    if (script && mod) {
        if (mod->isTextual()) {
            auto cl = script->getClass<JsTextModuleClass>();
            auto r = cl->construct(reinterpret_cast<JsModule*>(mod.get()), false);
            return r;
        } else if (mod->isHud()) {
            auto cl = script->getClass<JsHudModuleClass>();
            auto r = cl->construct(reinterpret_cast<JsModule*>(mod.get()), false);
            return r;
        }

        auto cl = script->getClass<JsModuleClass>();
        auto r = cl->construct(reinterpret_cast<JsModule*>(mod.get()), false);
        return r;
    }

    return null;
}

JsValueRef ClientScriptingObject::mmgrForEachModule(JsValueRef callee, bool isConstructor, JsValueRef* arguments,
                                                    unsigned short argCount, void* callbackState) {
    JsValueRef null;
    JS::JsGetUndefinedValue(&null);

    if (!Chakra::VerifyArgCount(argCount, 2)) return null;

    auto sz = Chakra::VerifyParameters({ { arguments[1], JsFunction } });
    if (!sz.success) {
        // handle
        Chakra::ThrowError(sz.str);
        return null;
    }

    auto thi = reinterpret_cast<ClientScriptingObject*>(callbackState);
    JsContextRef ctx;
    JS::JsGetCurrentContext(&ctx);
    JsScript* script = JsScript::getThis();

    auto cl = script->getClass<JsModuleClass>();
    if (!cl) {
        Chakra::ThrowError(L"INTERNAL ERROR: could not find Module class");
        return JS_INVALID_REFERENCE;
    }

    Onyln::getModuleManager().forEach([&](std::shared_ptr<Module> modul) {
        JsValueRef jsMod = JS_INVALID_REFERENCE;

        if (modul->isTextual()) {
            auto cl = script->getClass<JsTextModuleClass>();
            jsMod = cl->construct(reinterpret_cast<JsModule*>(modul.get()), false);
        } else if (modul->isHud()) {
            auto cl = script->getClass<JsHudModuleClass>();
            jsMod = cl->construct(reinterpret_cast<JsModule*>(modul.get()), false);
        } else {
            auto cl = script->getClass<JsModuleClass>();
            jsMod = cl->construct(reinterpret_cast<JsModule*>(modul.get()), false);
        }

        JsValueRef r[2] = { arguments[0], jsMod };
        JsValueRef res;
        Onyln::getPluginManager().handleErrors(Chakra::CallFunction(arguments[1], r, 2, &res));
        Chakra::Release(res);
        Chakra::Release(r[1]);
        return false;
    });

    return null;
}

JsValueRef ClientScriptingObject::cmgrRegisterCommandCallback(JsValueRef callee, bool isConstructor,
                                                              JsValueRef* arguments, unsigned short argCount,
                                                              void* callbackState) {
    JsValueRef undefined;
    JS::JsGetUndefinedValue(&undefined);
    if (!Chakra::VerifyArgCount(argCount, 2)) return undefined;

    auto sz = Chakra::VerifyParameters({ { arguments[1], JsObject } });
    if (!sz.success) {
        // handle
        Chakra::ThrowError(sz.str);
        return undefined;
    }

    JsCommand* cmd = nullptr;

    JS::JsGetExternalData(arguments[1], reinterpret_cast<void**>(&cmd));

    if (!cmd) {
        Chakra::ThrowError(L"Object is not a command");
        return undefined;
    }

    if (Onyln::getCommandManager().registerScriptCommand(cmd)) {
        JsScript::getThis()->addResource(cmd, [](void* obj) {
            if (!Onyln::getCommandManager().deregisterScriptCommand(reinterpret_cast<JsCommand*>(obj))) {
                Logger::Warn("Script command is already deregistered");
            }

            // hoepfully this doesnt double delete...
            // delete reinterpret_cast<JsCommand*>(obj);
        });
    }
    return undefined;
}

JsValueRef ClientScriptingObject::cmgrDeregisterCommandCallback(JsValueRef callee, bool isConstructor,
                                                                JsValueRef* arguments, unsigned short argCount,
                                                                void* callbackState) {
    JsValueRef undefined;
    JS::JsGetUndefinedValue(&undefined);
    if (!Chakra::VerifyArgCount(argCount, 2)) return undefined;

    auto sz = Chakra::VerifyParameters({ { arguments[1], JsObject } });
    if (!sz.success) {
        // handle
        Chakra::ThrowError(sz.str);
        return undefined;
    }

    JsCommand* cmd = nullptr;

    // TODO: check if its a script command

    JS::JsGetExternalData(arguments[1], reinterpret_cast<void**>(&cmd));

    // Onyln::getCommandManager().deregisterScriptCommand(cmd);
    JsScript::getThis()->removeResource(cmd);

    return undefined;
}

JsValueRef ClientScriptingObject::cmgrGetPrefixCallback(JsValueRef callee, bool isConstructor, JsValueRef* arguments,
                                                        unsigned short argCount, void* callbackState) {
    return Chakra::MakeString(util::StrToWStr(Onyln::getCommandManager().prefix));
}

JsValueRef ClientScriptingObject::smgrRegisterScreenCallback(JsValueRef callee, bool isConstructor,
                                                             JsValueRef* arguments, unsigned short argCount,
                                                             void* callbackState) {
    JsValueRef undefined;
    JS::JsGetUndefinedValue(&undefined);
    if (!Chakra::VerifyArgCount(argCount, 2)) return undefined;

    auto sz = Chakra::VerifyParameters({ { arguments[1], JsObject } });
    if (!sz.success) {
        // handle
        Chakra::ThrowError(sz.str);
        return undefined;
    }

    JsScreen* scn = nullptr;

    JS::JsGetExternalData(arguments[1], reinterpret_cast<void**>(&scn));

    if (!scn) {
        Chakra::ThrowError(L"Object is not a command");
        return undefined;
    }

    if (Onyln::getScreenManager().registerScriptScreen(scn)) {
        JsScript::getThis()->addResource(scn, [](void* obj) {
            if (!Onyln::getScreenManager().deregisterScriptScreen(reinterpret_cast<JsScreen*>(obj))) {
                Logger::Warn("Screen is already deregistered");
            }
        });
    }
    return undefined;
}
