#include "pch.h"
#include "Eventing.h"
#include "client/Onyln.h"

Eventing& Eventing::get() {
    return Onyln::getEventing();
}
