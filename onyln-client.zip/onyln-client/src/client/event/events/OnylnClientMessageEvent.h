#pragma once
class OnylnClientMessageEvent : public Event {
public:
    static const uint32_t hash = TOHASH(OnylnClientMessageEvent);

    OnylnClientMessageEvent(std::string const& msg)
        : message(msg) {}

    [[nodiscard]] std::string getMessage() { return message; }

private:
    std::string message;
};
