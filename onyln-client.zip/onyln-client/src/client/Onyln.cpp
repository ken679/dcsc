﻿#include "pch.h"
// Onyln.cpp : Defines the entry point for the application.
//
#include <cstdint>

#include "Onyln.h"
#include "BuildTimestamp.h"
#include "localization/LocalizeString.h"

#include "client/screen/TextBox.h"

#include "feature/module/ModuleManager.h"
#include "feature/command/CommandManager.h"
#include "script/PluginManager.h"

#include "config/ConfigManager.h"
#include "misc/ClientMessageQueue.h"
#include "misc/ServerDetection.h"
#include "misc/TempStorage.h"
#include "input/Keyboard.h"
#include "memory/hook/Hooks.h"
#include "event/Eventing.h"
#include "event/events/KeyUpdateEvent.h"
#include "event/events/RendererInitEvent.h"
#include "event/events/RendererCleanupEvent.h"
#include "event/events/FocusLostEvent.h"
#include "event/events/AppSuspendedEvent.h"
#include "event/events/UpdateEvent.h"
#include "event/events/CharEvent.h"
#include "event/events/ClickEvent.h"
#include "event/events/BobMovementEvent.h"
#include "event/events/LeaveGameEvent.h"

#include "mc/Addresses.h"

#include "mc/common/client/game/ClientInstance.h"
#include "mc/common/client/game/MinecraftGame.h"
#include "mc/common/client/game/FontRepository.h"
#include <winrt/windows.ui.viewmanagement.h>
#include <winrt/windows.storage.streams.h>

#include <mc/common/client/gui/ScreenView.h>
#include <mc/common/client/gui/controls/VisualTree.h>
#include <mc/common/client/gui/controls/UIControl.h>

#include "event/events/MouseReleaseEvent.h"
#include "mc/common/client/game/GameCore.h"

using namespace winrt;
using namespace winrt::Windows::Web::Http;
using namespace winrt::Windows::Web::Http::Filters;
using namespace winrt::Windows::Storage::Streams;
using namespace winrt::Windows::Storage;

#include "render/Renderer.h"
#include "screen/ScreenManager.h"
#include "render/asset/Assets.h"
#include "resource/Resource.h"
#include "feature/module/modules/game/Freelook.h"

using namespace std;

namespace {
    alignas(Eventing) char eventing[sizeof(Eventing)] = {};
    alignas(Onyln) char OnylnBuf[sizeof(Onyln)] = {};
    alignas(Renderer) char rendererBuf[sizeof(Renderer)] = {};
    alignas(ModuleManager) char mmgrBuf[sizeof(ModuleManager)] = {};
    alignas(ClientMessageQueue) char messageSinkBuf[sizeof(ClientMessageQueue)] = {};
    alignas(CommandManager) char commandMgrBuf[sizeof(CommandManager)] = {};
    alignas(ConfigManager) char configMgrBuf[sizeof(ConfigManager)] = {};
    alignas(SettingGroup) char mainSettingGroup[sizeof(SettingGroup)] = {};
    alignas(OnylnHooks) char hooks[sizeof(OnylnHooks)] = {};
    alignas(ScreenManager) char scnMgrBuf[sizeof(ScreenManager)] = {};
    alignas(Assets) char assetsBuf[sizeof(Assets)] = {};
    alignas(PluginManager) char scriptMgrBuf[sizeof(PluginManager)] = {};
    alignas(Keyboard) char keyboardBuf[sizeof(Keyboard)] = {};
    alignas(Notifications) char notificaitonsBuf[sizeof(Notifications)] = {};

    bool hasInjected = false;

    struct DllMainCall {
        HINSTANCE hinstDLL;
        DWORD fdwReason;
        LPVOID reserved;
    };

    DWORD WINAPI ejectThread(LPVOID module) {
        std::this_thread::sleep_for(250ms);
        FreeLibraryAndExitThread(static_cast<HMODULE>(module), 0);
    }

}

#define MVSIG(...) \
    ([]() -> std::pair<SigImpl*, SigImpl*> {\
/*if (SDK::internalVers == SDK::VLATEST) */return {&Signatures::__VA_ARGS__, &Signatures::__VA_ARGS__}; }\
/*if (SDK::internalVers == SDK::V1_20_40) { return {&Signatures_1_20_40::__VA_ARGS__, &Signatures::__VA_ARGS__}; }*/ \
/*if (SDK::internalVers == SDK::V1_20_30) { return {&Signatures_1_20_30::__VA_ARGS__, &Signatures::__VA_ARGS__}; }*/ \
/*if (SDK::internalVers == SDK::V1_19_51) { return {&Signatures_1_19_51::__VA_ARGS__, &Signatures::__VA_ARGS__}; }*/ \
/*return {&Signatures_1_18_12::__VA_ARGS__, &Signatures::__VA_ARGS__}; }*/\
)()

#define ONYLN_EXPORT extern "C" __declspec(dllexport)

ONYLN_EXPORT const char* OnylnGetDllVersion() noexcept {
    return Onyln::version.data();
}

ONYLN_EXPORT uint32_t OnylnGetSupportedMinecraftVersionCount() noexcept {
    return Onyln::supportedMinecraftVersions.size();
}

ONYLN_EXPORT const char* OnylnGetSupportedMinecraftVersion(uint32_t index) noexcept {
    if (index >= Onyln::supportedMinecraftVersions.size()) {
        return nullptr;
    }

    return Onyln::supportedMinecraftVersions[index].data();
}

DWORD __stdcall startThreadImpl(HINSTANCE dll) {
    BEGIN_ERROR_HANDLER
    // Needed for Logger
    new (messageSinkBuf) ClientMessageQueue;
    new (eventing) Eventing();
    new (OnylnBuf) Onyln;
    new (notificaitonsBuf) Notifications;

    std::filesystem::create_directory(util::GetOnylnPath());
    std::filesystem::create_directory(util::GetOnylnPath() / "Assets");
    OnylnTemp::cleanup();
    Logger::Setup();

#ifdef ONYLN_CRASH_REPORTING
    DebugExceptionHandler::Install();
#endif

#if defined(ONYLN_NIGHTLY)
    Logger::Info("Onyln Client [NIGHTLY] {}", Onyln::version);
#elif defined(ONYLN_DEBUG)
    Logger::Info("Onyln Client [DEBUG] {}", Onyln::version);
#else
    Logger::Info("Onyln Client {}", Onyln::version);
#endif

    char path[MAX_PATH] {};
    GetModuleFileNameA(nullptr, path, MAX_PATH);

    DWORD handle;
    DWORD size = GetFileVersionInfoSizeA(path, &handle);

    if (size == 0) {
        Logger::Fatal("Failed to get file version size");
    }

    std::vector<BYTE> data(size);
    if (!GetFileVersionInfoA(path, handle, size, data.data())) {
        Logger::Fatal("Failed to get file version");
    }

    VS_FIXEDFILEINFO* fileInfo = nullptr;
    UINT len = 0;

    if (VerQueryValueA(data.data(), "\\", reinterpret_cast<LPVOID*>(&fileInfo), &len)) {
        const auto major = HIWORD(fileInfo->dwFileVersionMS);
        const auto minor = LOWORD(fileInfo->dwFileVersionMS);
        const auto build = HIWORD(fileInfo->dwFileVersionLS);

        // TODO(1.26.50): Remove the pre-1.26.44 compatibility flag and its guarded workarounds.
        if (build < 44) Onyln::get().tmp2640Is4240 = true;

        Onyln::get().gameVersion = std::format("{}.{}.{}", major, minor, build);
    }

    /*winrt::Windows::ApplicationModel::Package package = winrt::Windows::ApplicationModel::Package::Current();
    winrt::Windows::ApplicationModel::PackageVersion version = package.Id().Version();

    {
        std::string rev = std::to_string(version.Build);
        std::string rem = rev.substr(0, rev.size() - 2); // remove 2 digits from end

        int ps = std::stoi(rem);
        std::stringstream ss;
        ss << version.Major << "." << version.Minor << "." << ps;// hacky
        Onyln::get().gameVersion = ss.str();
    }*/
    Logger::Info("Minecraft {}", Onyln::get().gameVersion);

    Logger::Info("Loading assets");
    Onyln::get().dllInst = dll;
    // ... init assets
    Onyln::get().initL10n();

    Logger::Info("Resolving signatures..");

    int sigCount = 0;
    int deadCount = 0;

    if (Onyln::supportsMinecraftVersion(Onyln::get().gameVersion)) {
        // not needed as it will always just be latest
        // SDK::internalVers = vers;
    } else {
        std::stringstream ss;
        ss << "Onyln Client does not support your version: " << Onyln::get().gameVersion
           << ". Onyln only supports the following versions:\n\n";

        for (const auto key : Onyln::supportedMinecraftVersions) {
            ss << key << "\n";
        }

        Logger::Warn(ss.str());
    }

    std::vector<std::pair<SigImpl*, SigImpl*>> sigList = {
        MVSIG(MainWindow__windowProcCallback),
        MVSIG(LevelRenderer_renderLevel),
        MVSIG(Options_getGamma),
        MVSIG(Options_getPerspective),
        MVSIG(Options_setPerspective),
        MVSIG(Options_getHideHand),
        MVSIG(ClientInstance_grabCursor),
        MVSIG(ClientInstance_releaseCursor),
        MVSIG(MultiPlayerLevel__subTick),
        MVSIG(ChatScreenController_sendChatMessage),
        MVSIG(GameCore_handleMouseInput),
        MVSIG(MinecraftGame_onDeviceLost),
        MVSIG(RenderController_getOverlayColor),
        MVSIG(ScreenView_setupAndRender),
        MVSIG(KeyMap),
        MVSIG(MinecraftGame__update),
        MVSIG(GpuInfo),
        MVSIG(RakPeer_GetAveragePing),
        MVSIG(ClientInputUpdateSystemInternal_tickUpdateClientInput),
        MVSIG(LocalPlayer_applyTurnDelta),
        MVSIG(ItemStackBase_getHoverName),
        MVSIG(I18n_getI18n),
        MVSIG(ItemStack_ItemStackBlock),
        MVSIG(ItemStackVtable),
        MVSIG(ItemStackBase_destructor),
        MVSIG(Vtable::Level),
        MVSIG(Tessellator_begin),
        MVSIG(Tessellator_vertex),
        MVSIG(Tessellator_color),
        MVSIG(MeshHelpers_renderMeshImmediately),
        MVSIG(BaseActorRenderContext_BaseActorRenderContext),
        MVSIG(ItemRenderer_renderGuiItemNew),
        MVSIG(ActorRenderDispatcher_render),
        MVSIG(MolangVariable__findOrAddVariableIndex),
        MVSIG(MolangVariableMap__getOrAddMolangVariable),
        MVSIG(LevelRendererPlayer_renderOutlineSelection),
        MVSIG(Dimension_getSkyColor),
        MVSIG(Dimension_getTimeOfDay),
        MVSIG(Dimension_tick),
        MVSIG(Misc::thirdPersonNametag),
        MVSIG(ItemStackBase_getDamageValue),
        MVSIG(MinecraftPackets_createPacket),
        MVSIG(Actor_attack),
        MVSIG(Actor_getNameTag),
        MVSIG(Actor_setNameTag),
        MVSIG(GuiMessageVector_emplaceBack),
        MVSIG(_updatePlayer),
        MVSIG(GameArguments__onUri),
        MVSIG(RenderMaterialGroup__common),
        MVSIG(GuiData_displayClientMessage),
        MVSIG(ClientInstanceScreenModel_forwardSoundSubtitle),
        MVSIG(BaseActorRenderer_renderText),
        MVSIG(AppPlatformGDK_releaseMouse),
        MVSIG(Misc::Platform_GameCore),
        MVSIG(Misc::mouseDevice),
    };

    // TODO(1.26.50): Remove the custom Windows 10 picker signature along with its compatibility hook.
    if (Onyln::get().tmp2640Is4240) {
        sigList.push_back(MVSIG(AppPlatform_GameCorePC_pickImage));
    }

    new (configMgrBuf) ConfigManager();
    if (!Onyln::getConfigManager().loadMaster()) {
        Logger::Fatal("Could not load master config!");
    } else {
        Logger::Info("Loaded master config");
    }
    new (mainSettingGroup) SettingGroup("global");

    // The Language setting is a special case because we need it to apply names to other global settings.
    Onyln::get().initLanguageSetting();
    Onyln::getConfigManager().applyLanguageConfig("language");

    Onyln::get().initSettings();
    Onyln::getConfigManager().applyGlobalConfig();

    new (mmgrBuf) ModuleManager;
    new (commandMgrBuf) CommandManager;
    new (scnMgrBuf) ScreenManager(); // needs to be initialized before renderer

    new (scriptMgrBuf) PluginManager();
    new (rendererBuf) Renderer();
    new (assetsBuf) Assets();

    for (auto& entry : sigList) {
        if (!entry.first->mod) continue;
        auto res = entry.first->resolve();
        if (!res) {
#if ONYLN_DEBUG
            Logger::Warn("Signature {} failed to resolve!", entry.first->name);
#endif
            deadCount++;
        } else {
            entry.second->result = entry.first->result;
            entry.second->scan_result = entry.first->scan_result;
            sigCount++;
        }
    }
#if ONYLN_DEBUG
    Logger::Info("Resolved {} signatures ({} dead)", sigCount, deadCount);
#endif

    MH_Initialize();
    new (hooks) OnylnHooks();

    new (keyboardBuf) Keyboard(reinterpret_cast<int*>(Signatures::KeyMap.result));

    Logger::Info("Waiting for game to load..");

    while (!SDK::ClientInstance::get()) {
        std::this_thread::sleep_for(10ms);
    }

    Onyln::get().initialize(dll);

    Logger::Info("Initialized Onyln Client");
    return 0ul;
    END_ERROR_HANDLER
}

DWORD __stdcall startThread(LPVOID context) {
#ifdef ONYLN_CRASH_REPORTING
    return static_cast<DWORD>(DebugExceptionHandler::RunWithSehGuard(
        [](void* param) -> std::uintptr_t {
            return startThreadImpl(static_cast<HINSTANCE>(param));
        },
        context, "Caught SEH exception in Onyln startup thread"));
#else
    return startThreadImpl(static_cast<HINSTANCE>(context));
#endif
}

BOOL WINAPI DllMainImpl(HINSTANCE hinstDLL, // handle to DLL module
                        DWORD fdwReason,    // reason for calling function
                        LPVOID reserved)    // reserved
{
    BEGIN_ERROR_HANDLER
    if (GetModuleHandleA("Minecraft.Windows.exe") != GetModuleHandleA(NULL)) return TRUE;

    if (fdwReason == DLL_PROCESS_ATTACH) {
        hasInjected = true;

        DisableThreadLibraryCalls(hinstDLL);
        CloseHandle(CreateThread(nullptr, 0, startThread, hinstDLL, 0, nullptr));
    } else if (fdwReason == DLL_PROCESS_DETACH) {
        if (reserved != nullptr) {
            hasInjected = false;
            return TRUE;
        }

        // Remove singletons

        Onyln::getHooks().disable();

        // Wait for all running hooks accross different threads to stop executing
        std::this_thread::sleep_for(200ms);

        if (!Onyln::get().isEjectReadyForRenderThread()) {
            Onyln::getConfigManager().saveCurrentConfig();
        }

        Onyln::getKeyboard().~Keyboard();
        Onyln::getModuleManager().~ModuleManager();
        Onyln::getClientMessageQueue().~ClientMessageQueue();
        Onyln::getCommandManager().~CommandManager();
        Onyln::getSettings().~SettingGroup();
        Onyln::getHooks().~OnylnHooks();
        Onyln::getEventing().~Eventing();
        Onyln::getRenderer().~Renderer();
        Onyln::getAssets().~Assets();
        Onyln::getScreenManager().~ScreenManager();
        Onyln::getPluginManager().~PluginManager();
        Onyln::getNotifications().~Notifications();
        Onyln::get().~Onyln();
        OnylnTemp::cleanup();

        MH_Uninitialize();

        hasInjected = false;
        Logger::Info("Onyln Client detached.");

#ifdef ONYLN_CRASH_REPORTING
        DebugExceptionHandler::Uninstall();
#endif
    }
    return TRUE; // Successful DLL_PROCESS_ATTACH.
    END_ERROR_HANDLER
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, // handle to DLL module
                    DWORD fdwReason,    // reason for calling function
                    LPVOID reserved)    // reserved
{
#ifdef ONYLN_CRASH_REPORTING
    DllMainCall call { hinstDLL, fdwReason, reserved };
    return static_cast<BOOL>(DebugExceptionHandler::RunWithSehGuard(
        [](void* context) -> std::uintptr_t {
            auto* call = static_cast<DllMainCall*>(context);
            return DllMainImpl(call->hinstDLL, call->fdwReason, call->reserved);
        },
        &call, "Caught SEH exception in Onyln DllMain"));
#else
    return DllMainImpl(hinstDLL, fdwReason, reserved);
#endif
}

Onyln& Onyln::get() noexcept {
    return *std::launder(reinterpret_cast<Onyln*>(OnylnBuf));
}

ModuleManager& Onyln::getModuleManager() noexcept {
    return *std::launder(reinterpret_cast<ModuleManager*>(mmgrBuf));
}

CommandManager& Onyln::getCommandManager() noexcept {
    return *std::launder(reinterpret_cast<CommandManager*>(commandMgrBuf));
}

ConfigManager& Onyln::getConfigManager() noexcept {
    return *std::launder(reinterpret_cast<ConfigManager*>(configMgrBuf));
}

ClientMessageQueue& Onyln::getClientMessageQueue() noexcept {
    return *std::launder(reinterpret_cast<ClientMessageQueue*>(messageSinkBuf));
}

SettingGroup& Onyln::getSettings() noexcept {
    return *std::launder(reinterpret_cast<SettingGroup*>(mainSettingGroup));
}

OnylnHooks& Onyln::getHooks() noexcept {
    return *std::launder(reinterpret_cast<OnylnHooks*>(hooks));
}

Eventing& Onyln::getEventing() noexcept {
    return *std::launder(reinterpret_cast<Eventing*>(eventing));
}

Renderer& Onyln::getRenderer() noexcept {
    return *std::launder(reinterpret_cast<Renderer*>(rendererBuf));
}

ScreenManager& Onyln::getScreenManager() noexcept {
    return *std::launder(reinterpret_cast<ScreenManager*>(scnMgrBuf));
}

Assets& Onyln::getAssets() noexcept {
    return *std::launder(reinterpret_cast<Assets*>(assetsBuf));
}

PluginManager& Onyln::getPluginManager() noexcept {
    return *std::launder(reinterpret_cast<PluginManager*>(scriptMgrBuf));
}

Keyboard& Onyln::getKeyboard() noexcept {
    return *std::launder(reinterpret_cast<Keyboard*>(keyboardBuf));
}

Notifications& Onyln::getNotifications() noexcept {
    return *std::launder(reinterpret_cast<Notifications*>(notificaitonsBuf));
}

std::optional<float> Onyln::getMenuBlur() {
    if (std::get<BoolValue>(this->menuBlurEnabled)) {
        return std::get<FloatValue>(this->menuBlur);
    }
    return std::nullopt;
}

std::vector<std::string> Onyln::getOnylnUsers() {
    return OnylnUsers;
}

int Onyln::getSelectedLanguage() {
    if (!l10nData) return 0;
    return l10nData->resolveLanguageSetting(clientLanguage.getSelectedKey());
}

void Onyln::queueEject() noexcept {
    // auto app = winrt::Windows::UI::ViewManagement::ApplicationView::GetForCurrentView();
    // app.Title(L"");
    SetWindowTextW(SDK::GameCore::get()->hwnd, L"Minecraft");
    if (this->shouldEject.exchange(true, std::memory_order_acq_rel)) {
        return;
    }
}

bool Onyln::isEjectQueued() const noexcept {
    return this->shouldEject.load(std::memory_order_acquire);
}

bool Onyln::isEjectReadyForRenderThread() const noexcept {
    return this->shouldEject.load(std::memory_order_acquire) &&
           this->mainThreadEjectCleanupComplete.load(std::memory_order_acquire);
}

void Onyln::completeEjectFromRenderThread() noexcept {
    if (!this->isEjectReadyForRenderThread()) {
        return;
    }

    if (Onyln::getRenderer().hasInitialized()) {
        this->releaseDeferredD2DResources();
        Onyln::getAssets().unloadAll();
        Onyln::getRenderer().shutdownForEject();
    }

    Onyln::getHooks().disable();

    if (!this->unloadStarted.exchange(true, std::memory_order_acq_rel)) {
        CloseHandle(CreateThread(nullptr, 0, ejectThread, dllInst, 0, nullptr));
    }
}

SDK::Font* Onyln::getFont() {
    switch (this->mcRendFont.getSelectedKey()) {
    case 0:
        return SDK::ClientInstance::get()->minecraftGame->getFontRepository()->getMinecraftFont();
    case 1:
        return SDK::ClientInstance::get()->minecraftGame->getFontRepository()->getSmoothFont();
    default:
        Logger::Fatal("Unknown font selected: {}", this->mcRendFont.getSelectedKey());
        throw std::runtime_error("Unknown font");
    }
}

void Onyln::initialize(HINSTANCE hInst) {
    this->dllInst = hInst;

    if (!controllerInput.start()) {
        Logger::Warn("Controller keybind input could not be initialized.");
    }

    Onyln::getPluginManager().init();
    Logger::Info("Script manager initialized.");

    Onyln::getEventing().listen<UpdateEvent, &Onyln::onUpdate>(this, 2);
    Onyln::getEventing().listen<KeyUpdateEvent, &Onyln::onKey>(this, 2);
    Onyln::getEventing().listen<RendererInitEvent, &Onyln::onRendererInit>(this, 2);
    Onyln::getEventing().listen<RendererCleanupEvent, &Onyln::onRendererCleanup>(this, 2);
    Onyln::getEventing().listen<AppSuspendedEvent, &Onyln::onSuspended>(this, 2);
    Onyln::getEventing().listen<CharEvent, &Onyln::onChar>(this, 2);
    Onyln::getEventing().listen<ClickEvent, &Onyln::onClick>(this, 2);
    Onyln::getEventing().listen<BobMovementEvent, &Onyln::onBobView>(this, 2);
    Onyln::getEventing().listen<LeaveGameEvent, &Onyln::onLeaveGame>(this, 2);
    Onyln::getEventing().listen<RenderLayerEvent, &Onyln::onRenderLayer>(this, 2);
    Onyln::getEventing().listen<RenderOverlayEvent, &Onyln::onRenderOverlay>(this, 2);
    Onyln::getEventing().listen<TickEvent, &Onyln::onTick>(this, 2);
    Onyln::getEventing().listen<MouseReleaseEvent, &Onyln::onMouseRelease>(this, 2);

    Logger::Info("Initialized Hooks");
    getHooks().enable();
    Logger::Info("Enabled Hooks");

    // doesn't work, maybe it's stored somewhere else too
    // if (SDK::internalVers < SDK::V1_20) {
    //    patchKey();
    //}
}

void Onyln::threadsafeInit() {
    this->gameThreadId = std::this_thread::get_id();
    // TODO: Onyln beta only
    // if (SDK::ClientInstance::get()->minecraftGame->xuid.size() > 0) wnd->postXUID();

    // auto app = winrt::Windows::UI::ViewManagement::ApplicationView::GetForCurrentView();
    std::string vstr(this->version);

#if defined(ONYLN_NIGHTLY)
    auto ws = util::StrToWStr("Onyln Client [NIGHTLY] " + gameVersion + " " + vstr + "/" + getBuildTimestamp());
#elif defined(ONYLN_DEBUG)
    auto ws = util::StrToWStr("Onyln Client [DEBUG] " + gameVersion + " " + vstr + "/" + getBuildTimestamp());
#else
    auto ws = util::StrToWStr("Onyln Client " + vstr);
#endif

    // app.Title(ws);
    SetWindowTextW(SDK::GameCore::get()->hwnd, ws.c_str());
    Onyln::getPluginManager().loadPrerunScripts();
    Logger::Info("Loaded startup scripts");

    Onyln::getConfigManager().applyModuleConfig();

    Onyln::getRenderer().setShouldInit();

    Onyln::getCommandManager().prefix = Onyln::get().getCommandPrefix();
    Onyln::getNotifications().push(LocalizeString::get("client.intro.welcome"));
    Onyln::getNotifications().push(
        util::FormatWString(LocalizeString::get("client.intro.menubutton"),
                            { util::StrToWStr(util::KeyToString(Onyln::get().getMenuKey().value)) }));
}

static void setModuleBlocked(std::string_view moduleName, bool shouldBlock) {
    std::vector<std::wstring> blockedList;
    Onyln::getModuleManager().forEach([&](std::shared_ptr<Module> mod) {
        if (mod->name() == moduleName && mod->isBlocked() != shouldBlock) {
            if (shouldBlock) {
                blockedList.push_back(mod->getDisplayName());
            }
            mod->setBlocked(shouldBlock);
        }
    });

    if (!blockedList.empty()) {
        std::wstring str;
        for (size_t i = 0; i < blockedList.size(); i++) {
            str += blockedList[i];
            if (i != blockedList.size() - 1) {
                str += L", ";
            }
        }
        Onyln::getNotifications().push(
            util::FormatWString(LocalizeString::get("client.modules.blockedOnServer.name"), { str }));
    }
}

void Onyln::updateModuleBlocking() {
    auto* connectionInfo = SDK::RemoteConnectorComposite::getConnectionInfo();
    const auto* server = ServerDetection::identify(connectionInfo);
    const bool isHiveOrGalaxite =
        server && (server->id == ServerDetection::ServerId::Hive || server->id == ServerDetection::ServerId::Galaxite);
    const bool isCubeCraft = server && server->id == ServerDetection::ServerId::CubeCraft;

    static_assert(std::is_base_of_v<Module, Freelook>);

    setModuleBlocked("Freelook", isHiveOrGalaxite);
    setModuleBlocked("Gyro", isCubeCraft);
}

std::string Onyln::getBuildTimestamp() {
#if defined(ONYLN_BUILD_TIMESTAMP)
    return ONYLN_BUILD_TIMESTAMP;
#else
    return OnylnBuild::getTimestamp();
#endif
}

std::wstring Onyln::GetCurrentModuleFilePath(HMODULE hModule) {
    std::vector<wchar_t> buffer(MAX_PATH);

    DWORD result = GetModuleFileNameW(hModule, buffer.data(), static_cast<DWORD>(buffer.size()));

    if (result > 0 && result < buffer.size()) {
        return std::wstring(buffer.data());
    } else if (result >= buffer.size()) {
        buffer.resize(result + 1);
        result = GetModuleFileNameW(hModule, buffer.data(), static_cast<DWORD>(buffer.size()));
        if (result > 0 && result < buffer.size()) {
            return std::wstring(buffer.data());
        }
    }

    return std::wstring(L"couldn't get file path");
}

void Onyln::initSettings() {
    {
        auto set = std::make_shared<Setting>("menuKey", LocalizeString::get("client.settings.menuKey.name"),
                                             LocalizeString::get("client.settings.menuKey.desc"));
        set->value = &this->menuKey;
        set->callback = [this](Setting& set) {
            Onyln::getScreenManager().get<HUDEditor>().key = this->getMenuKey();
        };
        this->getSettings().addSetting(set);
    }
    {
        auto set = std::make_shared<Setting>("ejectKey", LocalizeString::get("client.settings.ejectKey.name"),
                                             LocalizeString::get("client.settings.ejectKey.desc"));
        set->value = &this->ejectKey;
        this->getSettings().addSetting(set);
    }
    {
        auto set =
            std::make_shared<Setting>("menuBlurEnabled", LocalizeString::get("client.settings.menuBlurEnabled.name"),
                                      LocalizeString::get("client.settings.menuBlurEnabled.desc"));
        set->value = &this->menuBlurEnabled;
        this->getSettings().addSetting(set);
    }
    {
        auto set = std::make_shared<Setting>("useDX11", LocalizeString::get("client.settings.useDX11.name"),
                                             LocalizeString::get("client.settings.useDX11.desc"));
        set->value = &this->useDX11;
        this->getSettings().addSetting(set);
    }
    {
        auto set = std::make_shared<Setting>("forceDisableVSync",
                                             LocalizeString::get("client.settings.forceDisableVSync.name"),
                                             LocalizeString::get("client.settings.forceDisableVSync.desc"));
        set->value = &this->forceDisableVSync;
        this->getSettings().addSetting(set);
    }
    {
        auto set = std::make_shared<Setting>("commandPrefix", LocalizeString::get("client.settings.commandPrefix.name"),
                                             LocalizeString::get("client.settings.commandPrefix.desc"));
        set->value = &this->commandPrefix;
        set->visible = false;
        this->getSettings().addSetting(set);
    }
    {
        auto set = std::make_shared<Setting>("menuIntensity", LocalizeString::get("client.settings.menuIntensity.name"),
                                             LocalizeString::get("client.settings.menuIntensity.desc"));
        set->value = &this->menuBlur;
        set->min = FloatValue(1.f);
        set->max = FloatValue(30.f);
        set->interval = FloatValue(1.f);
        this->getSettings().addSetting(set);
    }
    {
        auto set = std::make_shared<Setting>("accentColor", LocalizeString::get("client.settings.accentColor.name"),
                                             LocalizeString::get("client.settings.accentColor.desc"));
        set->value = &this->accentColor;
        this->getSettings().addSetting(set);
    }

    {
        auto set = std::make_shared<Setting>("minViewBob", L"Minimal View Bob (UNSTABLE)",
                                             L"Only bob the item in hand, not the camera");
        set->value = &this->minimalViewBob;
        this->getSettings().addSetting(set);
    }

    {
        auto set = std::make_shared<Setting>("minecraftRenderer",
                                             LocalizeString::get("client.settings.minecraftRenderer.name"),
                                             LocalizeString::get("client.settings.minecraftRenderer.desc"));
        set->value = &this->minecraftRenderer;
        this->getSettings().addSetting(set);
    }

    {
        auto set = std::make_shared<Setting>("textShadow", LocalizeString::get("client.settings.textShadow.name"),
                                             LocalizeString::get("client.settings.textShadow.desc"));
        set->value = &this->textShadow;
        this->getSettings().addSetting(set);
    }

#ifdef ONYLN_DEBUG
    {
        auto set = std::make_shared<Setting>("debugTextRects", L"Debug Text Rects",
                                             L"Draw text bounds and highlight likely text overflow.");
        set->value = &this->debugTextRects;
        this->getSettings().addSetting(set);
    }
#endif

    {
        auto set = std::make_shared<Setting>("secondaryFont", LocalizeString::get("client.settings.secondaryFont.name"),
                                             LocalizeString::get("client.settings.secondaryFont.desc"));
        set->value = &this->secondaryFont;
        this->getSettings().addSetting(set);
    }

    {
        auto set =
            std::make_shared<Setting>("mcRendererFont", LocalizeString::get("client.settings.mcRendererFont.name"),
                                      LocalizeString::get("client.settings.mcRendererFont.desc"));
        set->enumData = &this->mcRendFont;
        set->value = set->enumData->getValue();
        set->enumData->addEntry({ 0, LocalizeString::get("client.settings.mcRendererFont.default.name"),
                                  LocalizeString::get("client.settings.mcRendererFont.default.desc") });
        set->enumData->addEntry({ 1, LocalizeString::get("client.settings.mcRendererFont.notoSans.name"),
                                  LocalizeString::get("client.settings.mcRendererFont.notoSans.desc") });
        this->getSettings().addSetting(set);
    }

    {
        // auto set = std::make_shared<Setting>("broadcastClientUsage", "Onyln Client Presence", "If you leave this on,
        // others with Onyln will see that you are using Onyln and you will see other people who use Onyln.");
        // set->value = &this->broadcastUsage;
        // this->getSettings().addSetting(set);
    }

    {
        auto set = std::make_shared<Setting>(""
                                             "centerCursor",
                                             LocalizeString::get("client.settings.centerCursor.name"),
                                             LocalizeString::get("client.settings.centerCursor.desc"));
        set->value = &this->centerCursorMenus;
        this->getSettings().addSetting(set);
    }

    {
        auto set = std::make_shared<Setting>("snapLines", LocalizeString::get("client.settings.snapLines.name"),
                                             LocalizeString::get("client.settings.snapLines.desc"));
        set->value = &this->snapLines;
        this->getSettings().addSetting(set);
    }

    {
        auto set = std::make_shared<Setting>("rgbSpeed", LocalizeString::get("client.settings.rgbSpeed.name"),
                                             LocalizeString::get("client.settings.rgbSpeed.desc"));
        set->value = &this->rgbSpeed;
        set->min = FloatValue(0.f);
        set->max = FloatValue(3.f);
        set->interval = FloatValue(0.1f);
        this->getSettings().addSetting(set);
    }
}

void Onyln::queueForUIRender(std::function<void(SDK::MinecraftUIRenderContext* ctx)> callback) {
    if (isEjectQueued()) return;
    this->uiRenderQueue.push(callback);
}

void Onyln::queueForClientThread(std::function<void()> callback) {
    if (isEjectQueued()) return;
    this->clientThreadQueue.push(callback);
}

void Onyln::queueForDXRender(std::function<void(ID2D1DeviceContext* ctx)> callback) {
    if (isEjectQueued()) return;
    this->dxRenderQueue.push(callback);
}

void Onyln::deferD2DResourceRelease(IUnknown* resource) noexcept {
    if (!resource) {
        return;
    }

    std::lock_guard lock(this->deferredD2DReleaseMutex);
    this->deferredD2DReleases.push_back(resource);
}

void Onyln::releaseDeferredD2DResources() noexcept {
    std::vector<IUnknown*> resources;
    {
        std::lock_guard lock(this->deferredD2DReleaseMutex);
        resources.swap(this->deferredD2DReleases);
    }

    for (auto* resource : resources) {
        resource->Release();
    }
}

void Onyln::initL10n() {
    l10nData = LocalizeData();
}

namespace {
    winrt::Windows::Foundation::IAsyncAction doDownloadAssets() {
        auto http = HttpClient();

        auto folderPath = util::GetOnylnPath() / "Assets";

        winrt::Windows::Foundation::Uri requestUri(
            util::StrToWStr("https://raw.githubusercontent.com/Imrglop/Latite-Releases/main/bin/ChakraCore.dll"));

        auto buffer = co_await http.GetBufferAsync(requestUri);

        std::filesystem::create_directories(folderPath);

        auto folder = co_await StorageFolder::GetFolderFromPathAsync(folderPath.wstring());
        auto file = co_await folder.CreateFileAsync(L"ChakraCore.dll", CreationCollisionOption::OpenIfExists);
        IRandomAccessStream stream = co_await file.OpenAsync(FileAccessMode::ReadWrite);

        DataWriter writer(stream);
        writer.WriteBuffer(buffer);
        writer.StoreAsync().get();
        writer.FlushAsync().get();
        co_return;
    }
}

void Onyln::downloadChakraCore() {
    if (!downloadingAssets) {
        this->downloadingAssets = true;
        doDownloadAssets();
    }
}

void Onyln::initLanguageSetting() {
    auto set = std::make_shared<Setting>("language", LocalizeString::get("client.settings.language.name"),
                                         LocalizeString::get("client.settings.language.desc"));
    set->enumData = &this->clientLanguage;
    set->value = set->enumData->getValue();
    set->userUpdateCallback = [](Setting&) {
        Onyln::get().onLanguageChanged();
    };

    set->enumData->addEntry({ LocalizeData::systemDefaultLanguageSettingValue,
                              LocalizeString::get("client.settings.language.systemDefault.name") });

    for (int i = 0; auto& lang : l10nData->getLanguages()) {
        set->enumData->addEntry({ i + 1, util::StrToWStr(lang->name) });
        i++;
    }
    this->getSettings().addSetting(set);
}

void Onyln::onLanguageChanged() {
    Onyln::getRenderer().refreshTextFormats();
    Onyln::getSettings().refreshLocalization();

    Onyln::getModuleManager().forEach([](std::shared_ptr<Module> mod) {
        mod->refreshLocalization();
    });

    Onyln::getCommandManager().refreshLocalization();
    Onyln::getScreenManager().get<ClickGUI>().requestModuleListRebuild();
    Onyln::getScreenManager().get<ClickGUI>().refreshLocalization();
}

void Onyln::onUpdate(Event& evGeneric) {
    auto& ev = reinterpret_cast<UpdateEvent&>(evGeneric);
    timings.update();
    auto now = std::chrono::system_clock::now();
    static auto lastSend = now;

    if (this->shouldEject.load(std::memory_order_acquire)) {
        if (!this->mainThreadEjectCleanupComplete.load(std::memory_order_acquire)) {
            Onyln::getScreenManager().shutdownForEject();
            Onyln::getConfigManager().saveCurrentConfig();
            Onyln::getModuleManager().shutdownForEject();
            Onyln::getPluginManager().unloadAll();
            this->controllerInput.stop();
            this->mainThreadEjectCleanupComplete.store(true, std::memory_order_release);
        }

        if (!Onyln::getRenderer().hasInitialized()) {
            this->completeEjectFromRenderThread();
        }
        return;
    }

    while (!this->clientThreadQueue.empty()) {
        auto& latest = this->clientThreadQueue.front();
        latest();
        this->clientThreadQueue.pop();
    }

    auto* connectionInfo = SDK::RemoteConnectorComposite::getConnectionInfo();

    if (!connectionInfo || (connectionInfo->unresolvedUrl.empty() && connectionInfo->hostIpAddress.empty() &&
                            connectionInfo->thirdPartyServerInfo.creatorName.empty())) {
        // updateModuleBlocking();
        getModuleManager().forEach([](std::shared_ptr<Module> mod) {
            mod->setBlocked(false);
        });
    }

    if (std::get<BoolValue>(centerCursorMenus) && SDK::ClientInstance::get()->minecraftGame->isCursorGrabbed()) {
        RECT r = { 0, 0, 0, 0 };
        GetClientRect(SDK::GameCore::get()->hwnd, &r);
        SetCursorPos((r.left + r.right) / 2, (r.top + r.bottom) / 2);
    }

    OnylnUsers = OnylnUsersDirty;

    if (!hasInit) {
        threadsafeInit();
        hasInit = true;
    }
    controllerInput.update();
    getKeyboard().findTextInput();
    Onyln::getPluginManager().runScriptingOperations();

    static bool lastDX11 = std::get<BoolValue>(this->useDX11);
    if (std::get<BoolValue>(useDX11) != lastDX11) {
        if (lastDX11) {
            Onyln::getClientMessageQueue().display(
                util::WFormat(LocalizeString::get("client.settings.dx11EnabledMsg.name")));
        } else {
            Onyln::getRenderer().setShouldReinit();
        }
        lastDX11 = std::get<BoolValue>(useDX11);
    }

    rgbHue += SDK::ClientInstance::get()->minecraft->timer->alpha * 0.005f * std::get<FloatValue>(rgbSpeed);
    if (rgbHue > 1.f) {
        rgbHue = 0.f;
    }
}

void Onyln::onKey(Event& evGeneric) {
    auto& ev = reinterpret_cast<KeyUpdateEvent&>(evGeneric);
    if (ev.getKey() == std::get<KeyValue>(ejectKey) && ev.isDown()) {
        this->queueEject();
        Logger::Info("Uninject key pressed");

        ev.setCancelled();
        return;
    }

    if (ev.isDown()) {
        for (auto& tb : textBoxes) {
            if (tb->isSelected()) {
                tb->onKeyDown(ev.getKey());
            }
        }
    }
}

void Onyln::onClick(Event& evGeneric) {
    auto& ev = reinterpret_cast<ClickEvent&>(evGeneric);
    timings.onClick(ev.getMouseButton(), ev.isDown());
}

void Onyln::onChar(Event& evGeneric) {
    auto& ev = reinterpret_cast<CharEvent&>(evGeneric);
    for (auto tb : textBoxes) {
        if (tb->isSelected()) {
            if (ev.isChar()) {
                tb->onChar(ev.getChar());
            } else {
                auto ch = ev.getChar();
                switch (ch) {
                case 0x1:
                    util::SetClipboardText(tb->getText());
                    break;
                case 0x2:
                    tb->setSelected(false);
                    break;
                case 0x3:
                    tb->reset();
                    break;
                default:
                    break;
                }
            }
            ev.setCancelled(true);
        }
    }
}

void Onyln::onRendererInit(Event&) {
    getAssets().unloadAll(); // should be safe even if we didn't load resources yet
    getAssets().loadAll();

    this->hudBlurBitmap = getRenderer().getCopiedBitmap();
    getRenderer().getDeviceContext()->CreateEffect(CLSID_D2D1GaussianBlur, gaussianBlurEffect.GetAddressOf());

    gaussianBlurEffect->SetInput(0, hudBlurBitmap.Get());
    gaussianBlurEffect->SetValue(D2D1_GAUSSIANBLUR_PROP_STANDARD_DEVIATION,
                                 std::get<FloatValue>(this->hudBlurIntensity));
    gaussianBlurEffect->SetValue(D2D1_GAUSSIANBLUR_PROP_BORDER_MODE, D2D1_BORDER_MODE_HARD);
    gaussianBlurEffect->SetValue(D2D1_GAUSSIANBLUR_PROP_OPTIMIZATION, D2D1_GAUSSIANBLUR_OPTIMIZATION_SPEED);

    getRenderer().getDeviceContext()->CreateBitmapBrush(hudBlurBitmap.Get(), this->hudBlurBrush.GetAddressOf());
}

void Onyln::onRendererCleanup(Event& ev) {
    this->hudBlurBitmap = nullptr;
    this->gaussianBlurEffect = nullptr;
    this->hudBlurBrush = nullptr;
}

void Onyln::onSuspended(Event& ev) {
    Onyln::getConfigManager().saveCurrentConfig();
    Logger::Info("Saved config");
}

void Onyln::onBobView(Event& ev) {
    if (std::get<BoolValue>(this->minimalViewBob)) {
        reinterpret_cast<Cancellable&>(ev).setCancelled(true);
    }
}

void Onyln::onLeaveGame(Event& ev) {
    getRenderer().clearTextCache();
}

void Onyln::onRenderLayer(Event& evG) {
    if (isEjectQueued()) return;

    auto& ev = reinterpret_cast<RenderLayerEvent&>(evG);
    while (!this->uiRenderQueue.empty()) {
        auto& latest = this->uiRenderQueue.front();
        latest(ev.getUIRenderContext());
        this->uiRenderQueue.pop();
    }
}

void Onyln::onRenderOverlay(Event& evG) {
    if (isEjectQueued()) return;

    auto& ev = reinterpret_cast<RenderOverlayEvent&>(evG);

    this->releaseDeferredD2DResources();

    if (getRenderer().getFontFamily2() != std::get<TextValue>(secondaryFont).str) {
        getRenderer().updateSecondaryFont(std::get<TextValue>(secondaryFont).str);
    }

    while (!this->dxRenderQueue.empty()) {
        auto& latest = this->dxRenderQueue.front();
        latest(ev.getDeviceContext());
        this->dxRenderQueue.pop();
    }
}

void Onyln::onPacketReceive(Event& evG) {
    // disabled
    auto& ev = reinterpret_cast<PacketReceiveEvent&>(evG);
}

void Onyln::onTick(Event& ev) {
    updateModuleBlocking();
}

void Onyln::onMouseRelease(Event& ev) {
    if (std::get<BoolValue>(centerCursorMenus)) {
        RECT r = { 0, 0, 0, 0 };
        GetClientRect(SDK::GameCore::get()->hwnd, &r);
        SetCursorPos((r.left + r.right) / 2, (r.top + r.bottom) / 2);
    }
}

void Onyln::loadLanguageConfig(std::shared_ptr<Setting> languageSetting) {
    this->getSettings().forEach([&](std::shared_ptr<Setting> set) {
        if (set->name() == languageSetting->name()) {
            std::visit(
                [&](auto&& obj) {
                    *set->value = obj;
                    set->update();
                },
                languageSetting->resolvedValue);
        }
    });
}

void Onyln::loadConfig(SettingGroup& gr) {
    gr.forEach([&](std::shared_ptr<Setting> set) {
        this->getSettings().forEach([&](std::shared_ptr<Setting> modSet) {
            if (modSet->name() == set->name()) {
                std::visit(
                    [&](auto&& obj) {
                        *modSet->value = obj;
                        modSet->update();
                    },
                    set->resolvedValue);
            }
        });
    });
}
