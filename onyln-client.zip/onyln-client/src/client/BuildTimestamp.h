#pragma once

namespace OnylnBuild {
    const char* getTimestamp() noexcept;
}
