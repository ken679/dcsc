#include "DXHooks.h"
#include "client/Onyln.h"
#include "client/render/Renderer.h"
#include "pch.h"

namespace {
    typedef HRESULT(WINAPI* CreateSwapChainForHWND_t)(IDXGIFactory2*, IUnknown*, HWND, const DXGI_SWAP_CHAIN_DESC1*,
                                                      const DXGI_SWAP_CHAIN_FULLSCREEN_DESC*, IDXGIOutput*,
                                                      IDXGISwapChain1**);

    bool tearingSupported = false;
    bool isForceDisableVSync = false;
    std::shared_ptr<Hook> PresentHook;
    std::shared_ptr<Hook> ResizeBuffersHook;
    std::shared_ptr<Hook> ResizeBuffers3Hook;
    std::shared_ptr<Hook> ExecuteCommandListsHook;

    constexpr UINT TearingPresentFlag = static_cast<UINT>(DXGI_PRESENT_ALLOW_TEARING);

    bool isFlipModel(DXGI_SWAP_EFFECT swapEffect) {
        return swapEffect == DXGI_SWAP_EFFECT_FLIP_SEQUENTIAL || swapEffect == DXGI_SWAP_EFFECT_FLIP_DISCARD;
    }

    bool canPresentWithTearing(IDXGISwapChain* chain, UINT existingPresentFlags) {
        if (!tearingSupported || !chain) return false;

        // Minecraft normally presents with either no flags or DXGI_PRESENT_RESTART. Avoid combining tearing with
        // unrelated presentation modes; support for those combinations varies between DXGI implementations.
        if ((existingPresentFlags & ~TearingPresentFlag) != 0) return false;

        DXGI_SWAP_CHAIN_DESC desc {};
        if (FAILED(chain->GetDesc(&desc)) || (desc.Flags & DXGI_SWAP_CHAIN_FLAG_ALLOW_TEARING) == 0 ||
            !isFlipModel(desc.SwapEffect)) {
            return false;
        }

        BOOL isFullscreen = FALSE;
        return SUCCEEDED(chain->GetFullscreenState(&isFullscreen, nullptr)) && !isFullscreen;
    }
}

void DXHooks::CheckForceDisableVSync() {
    isForceDisableVSync = Onyln::get().shouldForceDisableVSync();
}

void DXHooks::CheckTearingSupport() {
    tearingSupported = false;

    ComPtr<IDXGIFactory4> factory4;
    if (FAILED(CreateDXGIFactory1(IID_PPV_ARGS(&factory4)))) return;

    ComPtr<IDXGIFactory5> factory5;
    if (FAILED(factory4.As(&factory5))) return;

    BOOL allowTearing = FALSE;
    tearingSupported = SUCCEEDED(factory5->CheckFeatureSupport(DXGI_FEATURE_PRESENT_ALLOW_TEARING, &allowTearing,
                                                               sizeof(allowTearing))) &&
                       allowTearing;
}

CreateSwapChainForHWND_t origCreateSwapChain = nullptr;

HRESULT WINAPI DXHooks::CreateSwapChainForHWNDHook(IDXGIFactory2* factory, IUnknown* device, HWND hwnd,
                                                   const DXGI_SWAP_CHAIN_DESC1* desc,
                                                   const DXGI_SWAP_CHAIN_FULLSCREEN_DESC* pFullscreenDesc,
                                                   IDXGIOutput* output, IDXGISwapChain1** swapChain) {
    if (device) {
        ComPtr<ID3D12CommandQueue> queue;
        if (SUCCEEDED(device->QueryInterface(IID_PPV_ARGS(&queue))) && queue) {
            auto lock = Onyln::getRenderer().lock();
            Onyln::getRenderer().setCommandQueue(queue.Get());
        }
    }

    return origCreateSwapChain(factory, device, hwnd, desc, pFullscreenDesc, output, swapChain);
}

HRESULT __stdcall DXHooks::SwapChain_Present(IDXGISwapChain* chain, UINT SyncInterval, UINT Flags) {
    auto& renderer = Onyln::getRenderer();
    bool isGameSwapChain = false;
    if (Onyln::get().isEjectReadyForRenderThread()) {
        auto lock = renderer.lock();
        Onyln::get().completeEjectFromRenderThread();
    } else if (!Onyln::get().isEjectQueued() && !renderer.isResizeInProgress()) {
        auto lock = renderer.lock();
        if (!renderer.isResizeInProgress()) {
            if (renderer.hasInitialized()) {
                renderer.render();
            } else {
                renderer.init(chain);
            }

            isGameSwapChain = renderer.isGameSwapChain(chain);
        }
    }

    // static bool hasKilled = false;
    // if (!hasKilled) {
    //	ComPtr<ID3D12Device> d3d12Device;
    //	chain->GetDevice(IID_PPV_ARGS(&d3d12Device));
    //	if (d3d12Device) ((ID3D12Device5*)d3d12Device.Get())->RemoveDevice(); // kill dx
    //	hasKilled = true;
    // }

    auto originalPresent = PresentHook->oFunc<decltype(&SwapChain_Present)>();
    CheckForceDisableVSync();
    if (!isForceDisableVSync || !isGameSwapChain || (Flags & DXGI_PRESENT_TEST) != 0) {
        return originalPresent(chain, SyncInterval, Flags);
    }

    UINT presentFlags = Flags & ~TearingPresentFlag;
    if (canPresentWithTearing(chain, Flags)) {
        presentFlags |= TearingPresentFlag;
    }

    HRESULT result = originalPresent(chain, 0, presentFlags);
    if (result != DXGI_ERROR_INVALID_CALL || (SyncInterval == 0 && presentFlags == Flags)) {
        return result;
    }

    if ((presentFlags & TearingPresentFlag) != 0) {
        presentFlags &= ~TearingPresentFlag;
        result = originalPresent(chain, 0, presentFlags);
        if (result != DXGI_ERROR_INVALID_CALL) return result;
    }

    return originalPresent(chain, SyncInterval, Flags);
}

HRESULT __stdcall DXHooks::SwapChain_ResizeBuffers(IDXGISwapChain* chain, UINT BufferCount, UINT Width, UINT Height,
                                                   DXGI_FORMAT NewFormat, UINT SwapChainFlags) {
    Onyln::getRenderer().beginResize();
    const HRESULT result = ResizeBuffersHook->oFunc<decltype(&SwapChain_ResizeBuffers)>()(
        chain, BufferCount, Width, Height, NewFormat, SwapChainFlags);
    Onyln::getRenderer().endResize();
    return result;
}

HRESULT __stdcall DXHooks::SwapChain3_ResizeBuffers1(IDXGISwapChain3* chain, UINT BufferCount, UINT Width, UINT Height,
                                                     DXGI_FORMAT NewFormat, UINT SwapChainFlags,
                                                     const UINT* pCreationNodeMask, IUnknown* const* ppPresentQueue) {
    Onyln::getRenderer().beginResize();
    const HRESULT result = ResizeBuffers3Hook->oFunc<decltype(&SwapChain3_ResizeBuffers1)>()(
        chain, BufferCount, Width, Height, NewFormat, SwapChainFlags, pCreationNodeMask, ppPresentQueue);
    Onyln::getRenderer().endResize();
    return result;
}

HRESULT __stdcall DXHooks::CommandQueue_ExecuteCommandLists(ID3D12CommandQueue* queue, UINT NumCommandLists,
                                                            ID3D12CommandList* const* ppCommandLists) {
    if (queue) {
        auto desc = queue->GetDesc();
        if (desc.Type == D3D12_COMMAND_LIST_TYPE_DIRECT) {
            {
                auto lock = Onyln::getRenderer().lock();
                Onyln::getRenderer().setCommandQueue(queue);
            }
        }
    }

    return ExecuteCommandListsHook->oFunc<decltype(&CommandQueue_ExecuteCommandLists)>()(queue, NumCommandLists,
                                                                                         ppCommandLists);
}

DXHooks::DXHooks()
    : HookGroup("DirectX") {
    ComPtr<IDXGIFactory> factory;
    ComPtr<IDXGISwapChain> swapChain;
    ComPtr<IDXGIAdapter> adapter;
    ComPtr<ID3D11Device> device;
    ComPtr<ID3D12Device> device12;
    ComPtr<ID3D11DeviceContext> dctx;
    ComPtr<ID3D12CommandQueue> cqueue;

    DXHooks::CheckForceDisableVSync();
    DXHooks::CheckTearingSupport();

    ThrowIfFailed(CreateDXGIFactory(IID_PPV_ARGS(&factory)));
    ThrowIfFailed(factory->EnumAdapters(0, adapter.GetAddressOf()));

    DXGI_SWAP_CHAIN_DESC swapChainDesc = {};
    swapChainDesc.BufferCount = 2;
    swapChainDesc.BufferDesc.Width = 100;
    swapChainDesc.BufferDesc.Height = 100;
    swapChainDesc.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    swapChainDesc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    swapChainDesc.SwapEffect = DXGI_SWAP_EFFECT_FLIP_DISCARD;

    WNDCLASSEXW wnd { 0 };
    ZeroMemory(&wnd, sizeof(WNDCLASSEX));

    wnd.cbSize = sizeof(WNDCLASSEX);
    wnd.hInstance = Onyln::get().dllInst;
    wnd.lpszClassName = L"dummywnd";
    wnd.lpfnWndProc = DefWindowProc;
    wnd.lpszMenuName = 0;
    wnd.style = CS_SAVEBITS | CS_DROPSHADOW;

    RegisterClassExW(&wnd);

    HWND hWnd = CreateWindowExW(0, L"dummywnd", L"hi", WS_MINIMIZEBOX, 0, 0, 100, 100, nullptr, nullptr,
                                Onyln::get().dllInst, nullptr);

    swapChainDesc.OutputWindow = hWnd;
    swapChainDesc.SampleDesc.Count = 1;
    swapChainDesc.Windowed = TRUE;

    D3D_FEATURE_LEVEL lvl[] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_1 };

    D3D_FEATURE_LEVEL featureLevel;
    auto hr = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, lvl, 2, D3D11_SDK_VERSION,
                                            &swapChainDesc, swapChain.GetAddressOf(), device.GetAddressOf(),
                                            &featureLevel, dctx.GetAddressOf());

    uintptr_t* vftable = *reinterpret_cast<uintptr_t**>(swapChain.Get());
    uintptr_t* cqueueVftable = nullptr;

    {
        // DX12 only
        //
        //  dummy device
        if (SUCCEEDED(D3D12CreateDevice(adapter.Get(), D3D_FEATURE_LEVEL_11_0, IID_PPV_ARGS(&device12)))) {
            D3D12_COMMAND_QUEUE_DESC queueDesc = {};
            queueDesc.Flags = D3D12_COMMAND_QUEUE_FLAG_NONE;
            queueDesc.Type = D3D12_COMMAND_LIST_TYPE_DIRECT;

            ThrowIfFailed(device12->CreateCommandQueue(&queueDesc, IID_PPV_ARGS(&cqueue)));
            cqueueVftable = *reinterpret_cast<uintptr_t**>(cqueue.Get());
        }
    }

    DestroyWindow(hWnd);
    UnregisterClassW(L"dummywnd", Onyln::get().dllInst);

    ComPtr<IDXGIFactory2> factory2;
    if (SUCCEEDED(factory.As(&factory2))) {
        void** vtable = *(void***)factory2.Get();
        MH_CreateHook(vtable[15], DXHooks::CreateSwapChainForHWNDHook, (void**)&origCreateSwapChain);
        MH_EnableHook(vtable[15]);
    }

    PresentHook = addHook(vftable[8], SwapChain_Present, "IDXGISwapChain::Present");

    // We need both ResizeBuffers hooks as DX11 uses IDXGISwapChain::ResizeBuffers and DX12 uses
    // IDXGISwapChain3::ResizeBuffers1
    ResizeBuffersHook = addHook(vftable[13], SwapChain_ResizeBuffers, "IDXGISwapChain::ResizeBuffers");
    ResizeBuffers3Hook = addHook(vftable[39], SwapChain3_ResizeBuffers1, "IDXGISwapChain3::ResizeBuffers1");

    // Needed for D3D11On12 for DX12
    if (cqueueVftable)
        ExecuteCommandListsHook =
            addHook(cqueueVftable[10], CommandQueue_ExecuteCommandLists, "ID3D12CommandQueue::executeCommandLists");
    PresentHook->enable();
    ResizeBuffersHook->enable();
    ResizeBuffers3Hook->enable();
    if (cqueueVftable) ExecuteCommandListsHook->enable();
}
