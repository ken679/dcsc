#pragma once

#include "client/feature/module/Module.h"

class NoHurtCam final : public Module {
public:
    NoHurtCam()
        : Module("NoHurtCam", L"No Hurt Cam",
                 L"Suppresses the local hurt animation event that triggers camera shake.", GAME, nokeybind) {}
};
